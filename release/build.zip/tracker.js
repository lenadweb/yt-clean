/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/content/timeTracker.ts":
/*!************************************!*\
  !*** ./src/content/timeTracker.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TimeTracker = void 0;
var config_1 = __webpack_require__(/*! src/shared/storage/config */ "./src/shared/storage/config.ts");
var storage_1 = __webpack_require__(/*! src/shared/storage */ "./src/shared/storage.ts");
var common_1 = __webpack_require__(/*! src/shared/utils/common */ "./src/shared/utils/common.ts");
var date_1 = __webpack_require__(/*! src/shared/utils/date */ "./src/shared/utils/date.ts");
var TimeTracker = /** @class */ (function () {
    function TimeTracker() {
        var _this = this;
        this.key = 'spentTimeToday';
        this.intervalMs = 60000;
        this.intervalId = null;
        this.storage = new storage_1.Storage(config_1.DEFAULT_STORAGE);
        (0, common_1.sleep)(500).then(function () {
            _this.start();
        });
    }
    TimeTracker.prototype.isVideoPlaying = function () {
        var movieContainer = document.querySelector('#movie_player');
        if (movieContainer) {
            var video = movieContainer.getElementsByTagName('video')[0];
            return (!!video && !video.paused && !video.ended && video.readyState > 2);
        }
        return false;
    };
    TimeTracker.prototype.updateTime = function () {
        var current = this.storage.get(this.key);
        var todayStart = (0, date_1.getStartOfToday)();
        if (!current.tmstp || current.tmstp < todayStart) {
            this.storage.update(this.key, __assign(__assign({}, current), { value: '1', tmstp: todayStart }));
        }
        else {
            this.storage.update(this.key, __assign(__assign({}, current), { value: String((Number(current === null || current === void 0 ? void 0 : current.value) || 0) + 1), tmstp: current.tmstp }));
        }
    };
    TimeTracker.prototype.start = function () {
        var _this = this;
        if (this.intervalId)
            return;
        this.intervalId = setInterval(function () {
            var isVideoPlaying = _this.isVideoPlaying();
            if (isVideoPlaying) {
                _this.updateTime();
            }
        }, this.intervalMs);
    };
    TimeTracker.prototype.stop = function () {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
    };
    TimeTracker.prototype.reset = function () {
        var current = this.storage.get(this.key);
        this.storage.update(this.key, __assign(__assign({}, current), { value: '0', tmstp: (0, date_1.getStartOfToday)() }));
    };
    return TimeTracker;
}());
exports.TimeTracker = TimeTracker;
new TimeTracker();


/***/ }),

/***/ "./src/shared/storage.ts":
/*!*******************************!*\
  !*** ./src/shared/storage.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, exports) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Storage = void 0;
var Storage = /** @class */ (function () {
    function Storage(defaults) {
        var _this = this;
        this.listeners = [];
        this.settings = __assign({}, defaults);
        chrome.storage.local.get(null, function (data) {
            _this.settings = __assign(__assign({}, defaults), data);
            chrome.storage.local.set(_this.settings);
            _this.notifyListeners();
        });
        chrome.storage.onChanged.addListener(function (changes) {
            // @ts-ignore
            Object.keys(changes).forEach(function (key) {
                var _a;
                _this.settings[key] = (_a = changes[key].newValue) !== null && _a !== void 0 ? _a : defaults[key];
            });
            _this.notifyListeners();
        });
    }
    Storage.prototype.update = function (key, value) {
        var _a;
        this.settings[key] = value;
        chrome.storage.local.set((_a = {}, _a[key] = value, _a));
        this.notifyListeners();
    };
    Storage.prototype.get = function (key) {
        return this.settings[key];
    };
    Storage.prototype.onChange = function (callback) {
        this.listeners.push(callback);
    };
    Storage.prototype.notifyListeners = function () {
        this.listeners.forEach(function (cb) { return cb(); });
    };
    return Storage;
}());
exports.Storage = Storage;


/***/ }),

/***/ "./src/shared/storage/config.ts":
/*!**************************************!*\
  !*** ./src/shared/storage/config.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DEFAULT_STORAGE = void 0;
exports.DEFAULT_STORAGE = {
    isEnabled: true,
    hideShorts: { enabled: false },
    hideChannelBanner: { enabled: false },
    hideTranscriptSection: { enabled: false },
    adsFeedVideo: { enabled: false },
    defaultMusicPlaybackSpeed: { enabled: false },
    persistentCommentSort: { enabled: false, value: 'popular' },
    persistentQuality: { enabled: false, value: '1080' },
    persistentPlaybackSpeed: { enabled: false, value: '1.00' },
    adsYoutubeBanner: { enabled: false },
    adsSearchResults: { enabled: false },
    hideChannelTrailer: { enabled: false },
    autoNextShorts: { enabled: false },
    hideJams: { enabled: false },
    searchMode: { enabled: false },
    hideSearchTags: { enabled: false },
    hidePlayerSubtitlesButton: { enabled: false },
    hidePeopleMentioned: { enabled: false },
    hideDescriptionRelatedVideo: { enabled: false },
    hideSponsorVideo: { enabled: false },
    rightCommentMode: { enabled: false },
    hideEpisodesDescription: { enabled: false },
    hideCreateVideo: { enabled: false },
    voiceButtonInSearch: { enabled: false },
    hidePlayerWideSizePlayerButton: { enabled: false },
    hidePlayerMiniSizePlayerButton: { enabled: false },
    virtualKeyboard: { enabled: false },
    subscribeButton: { enabled: false },
    hideSponsorButton: { enabled: false },
    notificationButton: { enabled: false },
    relatedVideos: { enabled: false, maxVideo: 5 },
    hideLiveChat: { enabled: false },
    disableAutoplay: { enabled: false },
    commentsRightMode: { enabled: false },
    hideYourMovies: { enabled: false },
    hideNewsSection: { enabled: false },
    hidePlayerAutoplay: { enabled: false },
    autoOpenDescription: { enabled: false },
    hideMenuShorts: { enabled: false },
    hideMenuPlaylists: { enabled: false },
    hideMenuYourVideo: { enabled: false },
    hideMenuHistory: { enabled: false },
    hideMenuWatchLater: { enabled: false },
    hideMenuLikedVideos: { enabled: false },
    hideMenuSubscriptionsList: { enabled: false },
    hideMenuExploreMusic: { enabled: false },
    hideMenuExploreGaming: { enabled: false },
    hideMenuExploreSports: { enabled: false },
    hideMenuExploreNews: { enabled: false },
    hideMenuExploreTrending: { enabled: false },
    hideMenuMorePremium: { enabled: false },
    hideMenuMoreKids: { enabled: false },
    hideMenuMoreMusic: { enabled: false },
    hideMenuMoreStudio: { enabled: false },
    dailyTimeLimit: { enabled: false, valueInMinutes: String(60 * 2) },
    spentTimeToday: { enabled: false, value: String(0) },
};


/***/ }),

/***/ "./src/shared/utils/common.ts":
/*!************************************!*\
  !*** ./src/shared/utils/common.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.sleep = void 0;
var sleep = function (ms) {
    return new Promise(function (resolve) { return setTimeout(resolve, ms); });
};
exports.sleep = sleep;


/***/ }),

/***/ "./src/shared/utils/date.ts":
/*!**********************************!*\
  !*** ./src/shared/utils/date.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getStartOfToday = void 0;
function getStartOfToday() {
    var now = new Date();
    now.setHours(0, 0, 0, 0);
    return now.getTime();
}
exports.getStartOfToday = getStartOfToday;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/content/timeTracker.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=tracker.js.map