/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/shared/storage.ts":
/*!*******************************!*\
  !*** ./src/shared/storage.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, exports) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Storage = void 0;
var Storage = /** @class */ (function () {
    function Storage(defaults) {
        var _this = this;
        this.listeners = [];
        this.settings = __assign({}, defaults);
        chrome.storage.local.get(null, function (data) {
            _this.settings = __assign(__assign({}, defaults), data);
            chrome.storage.local.set(_this.settings);
            _this.notifyListeners();
        });
        chrome.storage.onChanged.addListener(function (changes) {
            // @ts-ignore
            Object.keys(changes).forEach(function (key) {
                var _a;
                _this.settings[key] = (_a = changes[key].newValue) !== null && _a !== void 0 ? _a : defaults[key];
            });
            _this.notifyListeners();
        });
    }
    Storage.prototype.update = function (key, value) {
        var _a;
        this.settings[key] = value;
        chrome.storage.local.set((_a = {}, _a[key] = value, _a));
        this.notifyListeners();
    };
    Storage.prototype.get = function (key) {
        return this.settings[key];
    };
    Storage.prototype.onChange = function (callback) {
        this.listeners.push(callback);
    };
    Storage.prototype.notifyListeners = function () {
        this.listeners.forEach(function (cb) { return cb(); });
    };
    return Storage;
}());
exports.Storage = Storage;


/***/ }),

/***/ "./src/shared/storage/config.ts":
/*!**************************************!*\
  !*** ./src/shared/storage/config.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DEFAULT_STORAGE = void 0;
exports.DEFAULT_STORAGE = {
    isEnabled: true,
    hideShorts: { enabled: false },
    hideChannelBanner: { enabled: false },
    hideTranscriptSection: { enabled: false },
    adsFeedVideo: { enabled: false },
    defaultMusicPlaybackSpeed: { enabled: false },
    persistentCommentSort: { enabled: false, value: 'popular' },
    persistentQuality: { enabled: false, value: '1080' },
    persistentPlaybackSpeed: { enabled: false, value: '1.00' },
    adsYoutubeBanner: { enabled: false },
    adsSearchResults: { enabled: false },
    hideChannelTrailer: { enabled: false },
    autoNextShorts: { enabled: false },
    hideJams: { enabled: false },
    searchMode: { enabled: false },
    hideSearchTags: { enabled: false },
    hidePlayerSubtitlesButton: { enabled: false },
    hidePeopleMentioned: { enabled: false },
    hideDescriptionRelatedVideo: { enabled: false },
    hideSponsorVideo: { enabled: false },
    rightCommentMode: { enabled: false },
    hideEpisodesDescription: { enabled: false },
    hideCreateVideo: { enabled: false },
    voiceButtonInSearch: { enabled: false },
    hidePlayerWideSizePlayerButton: { enabled: false },
    hidePlayerMiniSizePlayerButton: { enabled: false },
    virtualKeyboard: { enabled: false },
    subscribeButton: { enabled: false },
    hideSponsorButton: { enabled: false },
    notificationButton: { enabled: false },
    relatedVideos: { enabled: false, maxVideo: 5 },
    hideLiveChat: { enabled: false },
    disableAutoplay: { enabled: false },
    commentsRightMode: { enabled: false },
    hideYourMovies: { enabled: false },
    hideNewsSection: { enabled: false },
    hidePlayerAutoplay: { enabled: false },
    autoOpenDescription: { enabled: false },
    hideMenuShorts: { enabled: false },
    hideMenuPlaylists: { enabled: false },
    hideMenuYourVideo: { enabled: false },
    hideMenuHistory: { enabled: false },
    hideMenuWatchLater: { enabled: false },
    hideMenuLikedVideos: { enabled: false },
    hideMenuSubscriptionsList: { enabled: false },
    hideMenuExploreMusic: { enabled: false },
    hideMenuExploreGaming: { enabled: false },
    hideMenuExploreSports: { enabled: false },
    hideMenuExploreNews: { enabled: false },
    hideMenuExploreTrending: { enabled: false },
    hideMenuMorePremium: { enabled: false },
    hideMenuMoreKids: { enabled: false },
    hideMenuMoreMusic: { enabled: false },
    shortSpeedControl: { enabled: true },
    hideMenuMoreStudio: { enabled: false },
    dailyTimeLimit: { enabled: false, valueInMinutes: String(60 * 2) },
    spentTimeToday: { enabled: false, value: String(0) },
};


/***/ }),

/***/ "./src/shared/utils/browser.ts":
/*!*************************************!*\
  !*** ./src/shared/utils/browser.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.showElement = exports.hideElement = exports.clickElement = exports.waitForDocumentReady = exports.isOpera = void 0;
var isOpera = function () { return typeof (globalThis === null || globalThis === void 0 ? void 0 : globalThis.opr) !== 'undefined'; };
exports.isOpera = isOpera;
var waitForDocumentReady = function () {
    return new Promise(function (resolve) {
        if (document.readyState === 'complete') {
            resolve();
        }
        else {
            window.addEventListener('load', function () { return resolve(); }, { once: true });
        }
    });
};
exports.waitForDocumentReady = waitForDocumentReady;
var clickElement = function (selector) { var _a; return (_a = document.querySelector(selector)) === null || _a === void 0 ? void 0 : _a.click(); };
exports.clickElement = clickElement;
var hideElement = function (selector) {
    var el = document.querySelector(selector);
    if (el) {
        el.style.setProperty('opacity', '0', 'important');
    }
};
exports.hideElement = hideElement;
var showElement = function (selector) {
    var el = document.querySelector(selector);
    if (el) {
        el.style.removeProperty('opacity');
    }
};
exports.showElement = showElement;


/***/ }),

/***/ "./src/shared/utils/date.ts":
/*!**********************************!*\
  !*** ./src/shared/utils/date.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getStartOfToday = void 0;
function getStartOfToday() {
    var now = new Date();
    now.setHours(0, 0, 0, 0);
    return now.getTime();
}
exports.getStartOfToday = getStartOfToday;


/***/ }),

/***/ "./src/worker/index.ts":
/*!*****************************!*\
  !*** ./src/worker/index.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Background = void 0;
var browser_1 = __webpack_require__(/*! src/shared/utils/browser */ "./src/shared/utils/browser.ts");
var storage_1 = __webpack_require__(/*! src/shared/storage */ "./src/shared/storage.ts");
var config_1 = __webpack_require__(/*! src/shared/storage/config */ "./src/shared/storage/config.ts");
var date_1 = __webpack_require__(/*! src/shared/utils/date */ "./src/shared/utils/date.ts");
var Background = /** @class */ (function () {
    function Background() {
        this.isOpera = (0, browser_1.isOpera)();
        this.setEvents();
        this.storage = new storage_1.Storage(config_1.DEFAULT_STORAGE);
    }
    Background.prototype.setEvents = function () {
        if ((0, browser_1.isOpera)())
            return;
        if (typeof chrome.sidePanel !== 'undefined') {
            chrome.sidePanel
                .setPanelBehavior({ openPanelOnActionClick: true })
                .catch(function (error) { return console.error(error); });
            chrome.tabs.onUpdated.addListener(this.onUpdated.bind(this));
        }
    };
    Background.prototype.getBlockedPage = function () {
        var extensionID = chrome.runtime.id;
        return "chrome-extension://".concat(extensionID, "/blocked.html");
    };
    Background.prototype.onUpdated = function (tabId, changeInfo, tab) {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var isYoutube, limitIsEnabled;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!tab.url || tab.id === undefined)
                            return [2 /*return*/];
                        if (tabId === -1)
                            return [2 /*return*/];
                        isYoutube = new URL(tab.url).host.includes('youtube.com');
                        if (!isYoutube)
                            return [2 /*return*/];
                        limitIsEnabled = ((_a = this.storage.get('dailyTimeLimit')) === null || _a === void 0 ? void 0 : _a.enabled) || false;
                        if (!(this.checkIsTimeSpent() && limitIsEnabled)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.forceUpdateTab(tab.id, this.getBlockedPage())];
                    case 1:
                        _b.sent();
                        _b.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    Background.prototype.forceUpdateTab = function (tabId, url) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, chrome.tabs.update(tabId, { url: url })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    Background.prototype.getTimeSpent = function () {
        var current = this.storage.get('spentTimeToday');
        var todayStart = (0, date_1.getStartOfToday)();
        if (!current.tmstp || current.tmstp < todayStart) {
            return 0;
        }
        return Number(current === null || current === void 0 ? void 0 : current.value) || 0;
    };
    Background.prototype.checkIsTimeSpent = function () {
        var minutesSpent = this.getTimeSpent();
        if (minutesSpent) {
            var limit = this.storage.get('dailyTimeLimit');
            return Number(limit.valueInMinutes || '0') < minutesSpent;
        }
        return false;
    };
    return Background;
}());
exports.Background = Background;
function createBackgroundInstance() {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            return [2 /*return*/, new Background()];
        });
    });
}
createBackgroundInstance().then(function (instance) {
    globalThis.background = instance;
});


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/worker/index.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=worker.js.map