/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/content/index.ts":
/*!******************************!*\
  !*** ./src/content/index.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var config_1 = __webpack_require__(/*! src/shared/types/config */ "./src/shared/types/config.ts");
var config_2 = __webpack_require__(/*! src/shared/storage/config */ "./src/shared/storage/config.ts");
var config_3 = __webpack_require__(/*! src/shared/config */ "./src/shared/config/index.ts");
var getAttr_1 = __webpack_require__(/*! src/shared/utils/getAttr */ "./src/shared/utils/getAttr.ts");
var storage_1 = __webpack_require__(/*! src/shared/storage */ "./src/shared/storage.ts");
var browser_1 = __webpack_require__(/*! src/shared/utils/browser */ "./src/shared/utils/browser.ts");
var dom_1 = __webpack_require__(/*! src/shared/utils/dom */ "./src/shared/utils/dom.ts");
var Content = /** @class */ (function () {
    function Content(config, defaults) {
        var _this = this;
        this.elementCache = new Map();
        this.config = config;
        this.storage = new storage_1.Storage(defaults);
        this.currentUrl = window.location.href;
        this.observeUrlChanges();
        this.storage.onChange(function () { return _this.processActions(); });
        this.init();
    }
    Content.prototype.observeUrlChanges = function () {
        var _this = this;
        (0, browser_1.waitForDocumentReady)().then(function () {
            var observer = new MutationObserver(function () {
                if (window.location.href !== _this.currentUrl) {
                    _this.currentUrl = window.location.href;
                    _this.processActions();
                }
            });
            observer.observe(document.body, { childList: true, subtree: true });
        });
    };
    Content.prototype.init = function () {
        var _this = this;
        (0, dom_1.waitForElement)('html body').then(function () {
            _this.processActions();
        });
    };
    Content.prototype.processActions = function () {
        var _this = this;
        var enabledActions = this.getEnabledActions();
        enabledActions.forEach(function (item) {
            var e_1, _a;
            var _b, _c;
            var status = item.status, actions = item.actions, group = item.group;
            var _loop_1 = function (act) {
                var isTargetUrl = act.urlRegExp
                    ? act.urlRegExp.some(function (regexp) {
                        return new RegExp(regexp).test(_this.currentUrl);
                    })
                    : true;
                if (status.enabled && isTargetUrl && act.attr) {
                    if ((0, getAttr_1.getAttr)('more-from-yt-group') == act.attr) {
                        console.log(act);
                    }
                    (_b = document.body) === null || _b === void 0 ? void 0 : _b.setAttribute(act.attr, 'true');
                }
                else if (act.attr) {
                    (_c = document.body) === null || _c === void 0 ? void 0 : _c.removeAttribute(act.attr);
                }
                if (act.action === config_1.ElementActions.click && status.enabled) {
                    act.selectors.forEach(function (selector) {
                        (0, dom_1.waitForElement)(selector).then(function (element) {
                            if (element)
                                element.click();
                        });
                    });
                }
                if (act.action === config_1.ElementActions.custom &&
                    status.enabled &&
                    act.onEnable) {
                    act.onEnable().then(function (result) {
                        if (result && act.attr) {
                            _this.elementCache.set(act.attr, result);
                        }
                    });
                }
                if (act.action === config_1.ElementActions.custom &&
                    !status.enabled &&
                    act.onDisable) {
                    act.onDisable(_this.elementCache.get(act.attr));
                }
            };
            try {
                for (var actions_1 = __values(actions), actions_1_1 = actions_1.next(); !actions_1_1.done; actions_1_1 = actions_1.next()) {
                    var act = actions_1_1.value;
                    _loop_1(act);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (actions_1_1 && !actions_1_1.done && (_a = actions_1.return)) _a.call(actions_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            if (status.enabled &&
                group &&
                'onChange' in group &&
                group.onChange) {
                console.log(status.enabled, 'STATUS ENABLED', item);
                group.onChange(status.value);
            }
            if (!status.enabled &&
                group &&
                'onChange' in group &&
                group.onChange) {
                group.onChange('disabled');
            }
        });
    };
    Content.prototype.getEnabledActions = function () {
        var domActions = this.config.domActions;
        var settings = this.storage.settings;
        var isEnabled = settings.isEnabled;
        var collectActions = function (blocks) {
            return blocks.flatMap(function (block) { return block.groups || []; });
        };
        var extractEnabledActions = function (groups) {
            return groups.map(function (group) {
                var _a, _b;
                return ({
                    status: {
                        enabled: (isEnabled && ((_a = settings[group.storageKey]) === null || _a === void 0 ? void 0 : _a.enabled)) ||
                            false,
                        value: (_b = settings[group.storageKey]) === null || _b === void 0 ? void 0 : _b.value,
                    },
                    actions: 'actions' in group ? group.actions : [],
                    group: __assign(__assign({}, group), { actions: null }),
                });
            });
        };
        var domGroups = collectActions(domActions.flatMap(function (action) { return action.settings || []; }));
        var enabledActions = extractEnabledActions(domGroups);
        var fullEnabledGroupAction = domActions
            .flatMap(function (action) { return action.settings || []; })
            .map(function (action) {
            var allActionsIsEnabled = action.groups
                .map(function (item) { var _a; return !!((_a = settings[item.storageKey]) === null || _a === void 0 ? void 0 : _a.enabled); })
                .every(Boolean);
            if (action.onFullGroupEnabledActions) {
                console.log({ allActionsIsEnabled: allActionsIsEnabled });
            }
            return action.onFullGroupEnabledActions
                ? [
                    {
                        status: {
                            enabled: allActionsIsEnabled,
                            value: null,
                        },
                        actions: action.onFullGroupEnabledActions,
                        group: null,
                    },
                ]
                : [];
        })
            .flatMap(function (value) { return value; });
        var result = __spreadArray(__spreadArray([], __read(enabledActions), false), __read(fullEnabledGroupAction), false);
        console.log(result);
        return result;
    };
    return Content;
}());
new Content(config_3.CONFIG, config_2.DEFAULT_STORAGE);


/***/ }),

/***/ "./src/shared/config/feed.ts":
/*!***********************************!*\
  !*** ./src/shared/config/feed.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.feedConfig = void 0;
var config_1 = __webpack_require__(/*! src/shared/types/config */ "./src/shared/types/config.ts");
var getAttr_1 = __webpack_require__(/*! src/shared/utils/getAttr */ "./src/shared/utils/getAttr.ts");
exports.feedConfig = {
    title: 'Feed & Recommendations',
    settings: [
        {
            title: 'Content blocks',
            groups: [
                {
                    title: 'Shorts sections',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-shorts'),
                            selectors: [
                                'ytd-rich-section-renderer:has([is-shorts])',
                                'ytd-reel-shelf-renderer:has(#left-arrow)',
                                'ytd-reel-shelf-renderer.ytd-watch-next-secondary-results-renderer',
                                'ytd-reel-shelf-renderer',
                            ],
                        },
                    ],
                    storageKey: 'hideShorts',
                },
                {
                    title: 'Explore & News',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-news-section'),
                            selectors: [
                                'ytd-rich-section-renderer:has(#rich-shelf-header):not(:has(.shortsLockupViewModelHostThumbnail))',
                            ],
                        },
                    ],
                    storageKey: 'hideNewsSection',
                },
                {
                    title: 'Mixes & Playlists',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-jams'),
                            selectors: [
                                'ytd-rich-item-renderer:has(.yt-lockup-view-model-wiz--collection-stack-2)',
                            ],
                        },
                    ],
                    storageKey: 'hideJams',
                },
            ],
        },
        {
            title: 'Ads',
            groups: [
                {
                    title: 'YouTube Banners',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('youtube-banners'),
                            selectors: ['ytd-banner-promo-renderer'],
                        },
                    ],
                    storageKey: 'adsYoutubeBanner',
                },
                {
                    title: 'Sponsored search results',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('sponsored-search'),
                            selectors: ['ytd-search-pyv-renderer'],
                        },
                    ],
                    storageKey: 'adsSearchResults',
                },
                {
                    title: 'Sponsored feed video',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('sponsored-feed-video'),
                            selectors: [
                                'ytd-rich-item-renderer:has(ytd-ad-slot-renderer)',
                            ],
                        },
                    ],
                    storageKey: 'adsFeedVideo',
                },
            ],
        },
    ],
};


/***/ }),

/***/ "./src/shared/config/index.ts":
/*!************************************!*\
  !*** ./src/shared/config/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CONFIG = void 0;
var const_1 = __webpack_require__(/*! src/shared/const */ "./src/shared/const.ts");
var config_1 = __webpack_require__(/*! src/shared/types/config */ "./src/shared/types/config.ts");
var getAttr_1 = __webpack_require__(/*! src/shared/utils/getAttr */ "./src/shared/utils/getAttr.ts");
var template_1 = __webpack_require__(/*! src/shared/config/template */ "./src/shared/config/template.ts");
var feed_1 = __webpack_require__(/*! src/shared/config/feed */ "./src/shared/config/feed.ts");
var sidebar_1 = __webpack_require__(/*! src/shared/config/sidebar */ "./src/shared/config/sidebar.ts");
var video_1 = __webpack_require__(/*! src/shared/config/video */ "./src/shared/config/video.ts");
var limit_1 = __webpack_require__(/*! src/shared/config/limit */ "./src/shared/config/limit.ts");
exports.CONFIG = {
    domActions: [
        template_1.templateConfig,
        feed_1.feedConfig,
        video_1.videoConfig,
        sidebar_1.sidebarConfig,
        limit_1.limitConfig,
        {
            title: 'Other',
            settings: [
                {
                    title: 'Hide Related videos',
                    groups: [
                        {
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-related-videos'),
                                    selectors: ['#related'],
                                },
                            ],
                            storageKey: 'relatedVideos',
                        },
                    ],
                },
                {
                    title: 'Right comment mode',
                    groups: [
                        {
                            actions: [
                                {
                                    urlRegExp: [const_1.UrlRegExps.Watch],
                                    attr: (0, getAttr_1.getAttr)(),
                                    action: config_1.ElementActions.custom,
                                    selectors: [],
                                },
                            ],
                            storageKey: 'rightCommentMode',
                        },
                    ],
                },
                {
                    title: 'Hide related video',
                    groups: [
                        {
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-related-video-description'),
                                    selectors: [
                                        '#description #infocards-section',
                                    ],
                                },
                            ],
                            storageKey: 'hideDescriptionRelatedVideo',
                        },
                    ],
                },
            ],
        },
    ],
    storageActions: [],
};


/***/ }),

/***/ "./src/shared/config/limit.ts":
/*!************************************!*\
  !*** ./src/shared/config/limit.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.limitConfig = void 0;
var format_1 = __webpack_require__(/*! src/shared/utils/format */ "./src/shared/utils/format.tsx");
exports.limitConfig = {
    title: 'Time limit',
    settings: [
        {
            title: 'Daily limit',
            groups: [
                {
                    type: 'dropdown',
                    options: [
                        {
                            label: '30 minutes',
                            value: String(30),
                        },
                        {
                            label: '1 hour',
                            value: String(60),
                        },
                        {
                            label: '2 hours',
                            value: String(60 * 2),
                        },
                    ],
                    storageKey: 'dailyTimeLimit',
                },
                {
                    title: 'Time spent today',
                    type: 'subtitle',
                    subtitle: function (value) {
                        return value.value ? (0, format_1.formatTime)(Number(value.value)) : '0m';
                    },
                    actions: [],
                    storageKey: 'spentTimeToday',
                },
            ],
        },
    ],
};


/***/ }),

/***/ "./src/shared/config/sidebar.ts":
/*!**************************************!*\
  !*** ./src/shared/config/sidebar.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.sidebarConfig = void 0;
var config_1 = __webpack_require__(/*! src/shared/types/config */ "./src/shared/types/config.ts");
var getAttr_1 = __webpack_require__(/*! src/shared/utils/getAttr */ "./src/shared/utils/getAttr.ts");
exports.sidebarConfig = {
    title: 'Sidebar',
    settings: [
        {
            title: 'Main menu',
            groups: [
                {
                    title: 'Shorts',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-shorts'),
                            selectors: [
                                'ytd-mini-guide-entry-renderer[aria-label=Shorts]',
                                '#sections #items > ytd-guide-entry-renderer:has([title=Shorts])',
                            ],
                        },
                    ],
                    storageKey: 'hideMenuShorts',
                },
            ],
            withoutSwitch: true,
        },
        {
            title: 'You',
            // #sections > ytd-guide-section-renderer:has([href*='feed/trending'])
            groups: [
                {
                    title: 'History',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-history'),
                            selectors: [
                                '#section-items ytd-guide-entry-renderer:has([href="/feed/history"])',
                            ],
                        },
                    ],
                    storageKey: 'hideMenuHistory',
                },
                {
                    title: 'Playlists',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-playlists'),
                            selectors: [
                                '#section-items ytd-guide-entry-renderer:has([href="/feed/playlists"])',
                            ],
                        },
                    ],
                    storageKey: 'hideMenuPlaylists',
                },
                {
                    title: 'Your video',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-your-video'),
                            selectors: [
                                '#section-items ytd-guide-entry-renderer:has([href*="studio.youtube"])',
                            ],
                        },
                    ],
                    storageKey: 'hideMenuYourVideo',
                },
                {
                    title: 'Watch later',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-watch-later'),
                            selectors: [
                                '#section-items ytd-guide-entry-renderer:has([href="/playlist?list=WL"])',
                            ],
                        },
                    ],
                    storageKey: 'hideMenuWatchLater',
                },
                {
                    title: 'Liked videos',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-liked-videos'),
                            selectors: [
                                '#section-items ytd-guide-entry-renderer:has([href="/playlist?list=LL"])',
                            ],
                        },
                    ],
                    storageKey: 'hideMenuLikedVideos',
                },
                {
                    title: 'Your Movies',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-your-movies'),
                            selectors: [
                                '#section-items ytd-guide-entry-renderer:has([href*="/feed/storefront"])',
                            ],
                        },
                    ],
                    storageKey: 'hideYourMovies',
                },
            ],
            onFullGroupEnabledActions: [
                {
                    action: config_1.ElementActions.hide,
                    attr: (0, getAttr_1.getAttr)('full-group-you'),
                    selectors: [
                        '#sections ytd-guide-collapsible-section-entry-renderer:has([href="/feed/history"])',
                    ],
                },
            ],
        },
        {
            title: 'Subscriptions list',
            groups: [
                {
                    title: 'Subscriptions list',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-subscriptions-list'),
                            selectors: [
                                "#sections ytd-guide-section-renderer:has([href*='@'])",
                                "ytd-mini-guide-renderer ytd-mini-guide-entry-renderer:has([href='/feed/subscriptions'])",
                            ],
                        },
                    ],
                    storageKey: 'hideMenuSubscriptionsList',
                },
            ],
            withoutCheckboxes: true,
        },
        {
            title: 'Explore',
            groups: [
                {
                    title: 'Trending',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-explore-trending'),
                            selectors: [
                                "#sections ytd-guide-entry-renderer:has([href*='feed/trending'])",
                            ],
                        },
                    ],
                    storageKey: 'hideMenuExploreTrending',
                },
                {
                    title: 'Music',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-explore-music'),
                            selectors: [
                                "#sections ytd-guide-entry-renderer:has([href*='channel/UC-9'])",
                            ],
                        },
                    ],
                    storageKey: 'hideMenuExploreMusic',
                },
                {
                    title: 'Gaming',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-explore-gaming'),
                            selectors: [
                                "#sections ytd-guide-entry-renderer:has([href='/gaming'])",
                            ],
                        },
                    ],
                    storageKey: 'hideMenuExploreGaming',
                },
                {
                    title: 'News',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-explore-news'),
                            selectors: [
                                "#sections ytd-guide-entry-renderer:has([href*='UCYfdidRxbB8Qhf0Nx7ioOYw'])",
                            ],
                        },
                    ],
                    storageKey: 'hideMenuExploreNews',
                },
                {
                    title: 'Sports',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-explore-sports'),
                            selectors: [
                                "#sections ytd-guide-entry-renderer:has([href*='UCEgdi0XIXXZ-qJOFPf4JSKw'])",
                            ],
                        },
                    ],
                    storageKey: 'hideMenuExploreSports',
                },
            ],
            onFullGroupEnabledActions: [
                {
                    action: config_1.ElementActions.hide,
                    attr: (0, getAttr_1.getAttr)('explore-group'),
                    selectors: [
                        "#sections ytd-guide-section-renderer:has([href*='feed/trending'])",
                    ],
                },
            ],
        },
        {
            title: 'More from YouTube',
            groups: [
                {
                    title: 'YouTube Premium',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-more-premium'),
                            selectors: [
                                "#sections #items ytd-guide-entry-renderer:has([href='/premium'])",
                            ],
                        },
                    ],
                    storageKey: 'hideMenuMorePremium',
                },
                {
                    title: 'YouTube Music',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-more-music'),
                            selectors: [
                                "#sections #items ytd-guide-entry-renderer:has([href='https://music.youtube.com/'])",
                            ],
                        },
                    ],
                    storageKey: 'hideMenuMoreMusic',
                },
                {
                    title: 'YouTube Kids',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-more-kids'),
                            selectors: [
                                "#sections #items ytd-guide-entry-renderer:has([href*='youtubekids.com'])",
                            ],
                        },
                    ],
                    storageKey: 'hideMenuMoreKids',
                },
                {
                    title: 'YouTube Studio',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-menu-more-studio'),
                            selectors: [
                                "#sections #items ytd-guide-entry-renderer:has([href*='studio.youtube.com'])",
                            ],
                        },
                    ],
                    storageKey: 'hideMenuMoreStudio',
                },
            ],
            onFullGroupEnabledActions: [
                {
                    action: config_1.ElementActions.hide,
                    attr: (0, getAttr_1.getAttr)('more-from-yt-group'),
                    selectors: [
                        "#sections ytd-guide-section-renderer:has([href='https://music.youtube.com/'])",
                    ],
                },
            ],
        },
    ],
};


/***/ }),

/***/ "./src/shared/config/template.ts":
/*!***************************************!*\
  !*** ./src/shared/config/template.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.templateConfig = void 0;
var config_1 = __webpack_require__(/*! src/shared/types/config */ "./src/shared/types/config.ts");
var getAttr_1 = __webpack_require__(/*! src/shared/utils/getAttr */ "./src/shared/utils/getAttr.ts");
var const_1 = __webpack_require__(/*! src/shared/const */ "./src/shared/const.ts");
var cookies_1 = __webpack_require__(/*! src/shared/utils/cookies */ "./src/shared/utils/cookies.ts");
exports.templateConfig = {
    title: 'Basic template',
    settings: [
        {
            title: 'Search Bar',
            groups: [
                {
                    title: 'Voice search button',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-voice-search'),
                            selectors: ['#voice-search-button'],
                        },
                    ],
                    storageKey: 'voiceButtonInSearch',
                },
                {
                    title: 'Virtual keyboard button',
                    actions: [
                        {
                            title: 'Virtual keyboard button',
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-virtual-keyboard'),
                            selectors: [
                                '.ytSearchboxComponentYtdTextInputAssistantWrapper',
                            ],
                        },
                    ],
                    storageKey: 'virtualKeyboard',
                },
                {
                    title: 'Search tags',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-search-tags'),
                            urlRegExp: [const_1.UrlRegExps.Home],
                            selectors: [
                                '.ytd-feed-filter-chip-bar-renderer',
                                '#header.ytd-rich-grid-renderer',
                                'yt-related-chip-cloud-renderer',
                            ],
                        },
                    ],
                    storageKey: 'hideSearchTags',
                },
            ],
        },
        {
            title: 'Actions & user',
            groups: [
                {
                    title: 'Upload button',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-create-video'),
                            selectors: ['#buttons .ytd-masthead:first-child'],
                        },
                    ],
                    storageKey: 'hideCreateVideo',
                },
                {
                    title: 'Notifications',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-notification-button'),
                            selectors: [
                                'ytd-notification-topbar-button-renderer.ytd-masthead',
                            ],
                        },
                    ],
                    storageKey: 'notificationButton',
                },
            ],
        },
        {
            title: 'Search Mode',
            groups: [
                {
                    actions: [
                        {
                            urlRegExp: [const_1.UrlRegExps.Watch, const_1.UrlRegExps.Home],
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('search-mode-hide-elements'),
                            selectors: [
                                'ytd-two-column-browse-results-renderer',
                                '.html5-endscreen',
                                'button.ytp-size-button.ytp-button',
                                '#related',
                            ],
                        },
                        {
                            urlRegExp: [const_1.UrlRegExps.Watch],
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('search-mode'),
                            selectors: ['#columns > #secondary'],
                        },
                        {
                            urlRegExp: [const_1.UrlRegExps.Watch],
                            action: config_1.ElementActions.custom,
                            attr: (0, getAttr_1.getAttr)('search-mode'),
                            selectors: [],
                            onEnable: function () { return __awaiter(void 0, void 0, void 0, function () {
                                return __generator(this, function (_a) {
                                    cookies_1.cookie.remove('wide');
                                    cookies_1.cookie.set('wide', '1');
                                    return [2 /*return*/];
                                });
                            }); },
                            onDisable: function () {
                                cookies_1.cookie.remove('wide');
                                cookies_1.cookie.set('wide', '0');
                            },
                        },
                        {
                            urlRegExp: [const_1.UrlRegExps.Watch, const_1.UrlRegExps.Home],
                            action: config_1.ElementActions.customStyles,
                            attr: (0, getAttr_1.getAttr)('search-mode'),
                            selectors: [],
                            customStyles: [
                                "#primary {\n                                            width: 100%!important;\n                                            display: block!important;\n                                            max-width: none!important;\n                                            padding: 20px 0!important;\n                                            margin: 0!important;\n                                            box-sizing: border-box!important;\n                                        }",
                                "#columns {\n                                            width: 100%!important;\n                                            display: block!important;\n                                            margin: 0 auto!important;\n                                        }",
                                "#page-manager:has(ytd-watch-flexy:not([fullscreen])) {\n                                            width: 82.5vw!important;\n                                            display: block!important;\n                                            margin: 0 auto!important;\n                                            padding-top: 68px!important;\n                                        }",
                                "ytd-watch-flexy:not([fullscreen]) #full-bleed-container {\n                                            overflow: hidden!important;\n                                            border-radius: 12px!important;\n                                        }",
                                "#columns {\n                                            max-widht: none!important;\n                                        }",
                                "#primary {\n                                            margin: 10px 0 0 0!important;\n                                            padding: 0!important;\n                                            width: 100%!important;\n                                            max-width: none!important;\n                                        }",
                                "#description {\n                                            margin: 12px 0!important;\n                                            width: 100%!important;\n                                        }",
                                "ytd-watch-flexy:not([fullscreen]) #teaser-carousel {\n                                            width: 100%!important;\n                                            margin: 12px 0!important;\n                                        }",
                                "ytd-watch-flexy:not([fullscreen]) #ytd-player {\n                                            overflow: hidden!important;\n                                            border-radius: 12px!important;\n                                        }",
                                "ytd-watch-flexy[full-bleed-player]:not([fullscreen]) #full-bleed-container.ytd-watch-flexy {\n                                            height: 46.40625vw!important;\n                                        }",
                                "#bottom-row.ytd-watch-metadata {\n                                            flex-direction: column!important;\n                                            margin: 0!important;\n                                        }",
                            ],
                        },
                    ],
                    storageKey: 'searchMode',
                },
            ],
            withoutCheckboxes: true,
        },
    ],
};


/***/ }),

/***/ "./src/shared/config/video.ts":
/*!************************************!*\
  !*** ./src/shared/config/video.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.videoConfig = void 0;
var config_1 = __webpack_require__(/*! src/shared/types/config */ "./src/shared/types/config.ts");
var getAttr_1 = __webpack_require__(/*! src/shared/utils/getAttr */ "./src/shared/utils/getAttr.ts");
var const_1 = __webpack_require__(/*! src/shared/const */ "./src/shared/const.ts");
var yt_1 = __webpack_require__(/*! src/shared/utils/yt */ "./src/shared/utils/yt.ts");
var dom_1 = __webpack_require__(/*! src/shared/utils/dom */ "./src/shared/utils/dom.ts");
var browser_1 = __webpack_require__(/*! src/shared/utils/browser */ "./src/shared/utils/browser.ts");
exports.videoConfig = {
    title: 'Video Playback & Channel',
    settings: [
        {
            title: 'Persistent playback speed',
            groups: [
                {
                    options: [
                        {
                            label: '0.5x',
                            value: '0.50',
                        },
                        {
                            label: '0.75x',
                            value: '0.75',
                        },
                        {
                            label: '1x',
                            value: '1.00',
                        },
                        {
                            label: '1.25x',
                            value: '1.25',
                        },
                        {
                            label: '1.5x',
                            value: '1.50',
                        },
                        {
                            label: '1.75x',
                            value: '1.75',
                        },
                        {
                            label: '2x',
                            value: '2.25',
                        },
                        {
                            label: '2.5x',
                            value: '2.50',
                        },
                        {
                            label: '2.75x',
                            value: '2.75',
                        },
                        {
                            label: '3x',
                            value: '3.00',
                        },
                    ],
                    type: 'dropdown',
                    storageKey: 'persistentPlaybackSpeed',
                    onChange: function (value) {
                        console.log('change speed', value);
                        if (value === 'disabled') {
                            return;
                        }
                        var isTargetUrl = [
                            const_1.UrlRegExps.Watch,
                            const_1.UrlRegExps.Channel,
                        ].some(function (item) {
                            return new RegExp(item).test(window.location.href);
                        });
                        if (isTargetUrl) {
                            (0, yt_1.setPlaybackSpeed)(value);
                        }
                    },
                },
            ],
        },
        {
            title: 'Set 1x playback speed for music videos',
            groups: [
                {
                    actions: [
                        {
                            urlRegExp: [const_1.UrlRegExps.Watch],
                            attr: (0, getAttr_1.getAttr)(),
                            action: config_1.ElementActions.custom,
                            selectors: [],
                        },
                    ],
                    storageKey: 'defaultMusicPlaybackSpeed',
                    onChange: function (value) { return __awaiter(void 0, void 0, void 0, function () {
                        var isTargetUrl, isMusicVideo;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    isTargetUrl = new RegExp(const_1.UrlRegExps.Watch).test(window.location.href);
                                    if (!(value !== 'disabled' && isTargetUrl)) return [3 /*break*/, 5];
                                    return [4 /*yield*/, (0, dom_1.waitForElement)('.html5-video-player:not(.unstarted-mode) video[src]')];
                                case 1:
                                    _a.sent();
                                    return [4 /*yield*/, (0, dom_1.waitForElement)('yt-page-navigation-progress[hidden]')];
                                case 2:
                                    _a.sent();
                                    return [4 /*yield*/, (0, dom_1.waitForElement)('.html5-video-player:not(.unstarted-mode) video[src]')];
                                case 3:
                                    _a.sent();
                                    (0, browser_1.hideElement)('.ytp-popup.ytp-settings-menu');
                                    (0, browser_1.clickElement)('.ytp-settings-button');
                                    (0, browser_1.clickElement)('.ytp-settings-button');
                                    (0, browser_1.showElement)('.ytp-popup.ytp-settings-menu');
                                    return [4 /*yield*/, (0, dom_1.waitForElement)(".ytp-drc-menu-item[aria-disabled='true']", 5000)];
                                case 4:
                                    isMusicVideo = _a.sent();
                                    console.log({ isMusicVideo: isMusicVideo });
                                    if (isMusicVideo) {
                                        (0, yt_1.setPlaybackSpeed)('1.00');
                                    }
                                    _a.label = 5;
                                case 5: return [2 /*return*/];
                            }
                        });
                    }); },
                },
            ],
            withoutCheckboxes: true,
        },
        {
            title: 'Persistent video quality',
            groups: [
                {
                    onChange: function (value) { return __awaiter(void 0, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            // todo:
                            if (value === 'disabled') {
                                value = '1080';
                            }
                            (0, yt_1.setQualityVideo)(value);
                            return [2 /*return*/];
                        });
                    }); },
                    options: [
                        {
                            label: '2160p',
                            value: '2160',
                        },
                        {
                            label: '1440p',
                            value: '1440',
                        },
                        {
                            label: '1080p',
                            value: '1080',
                        },
                        {
                            label: '720p',
                            value: '720',
                        },
                        {
                            label: '480p',
                            value: '480',
                        },
                        {
                            label: '360p',
                            value: '360',
                        },
                        {
                            label: '240p',
                            value: '240',
                        },
                        {
                            label: '144p',
                            value: '144',
                        },
                    ],
                    type: 'dropdown',
                    storageKey: 'persistentQuality',
                },
            ],
        },
        {
            title: 'Persistent comment sort',
            groups: [
                {
                    onChange: function (value) { return __awaiter(void 0, void 0, void 0, function () {
                        var waitSelector, selector, element;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    if (value === 'disabled')
                                        return [2 /*return*/];
                                    waitSelector = 'ytd-comments#comments ytd-item-section-renderer:not([continuation-is-reloading])';
                                    selector = "#sort-menu tp-yt-paper-menu-button tp-yt-iron-dropdown a.yt-simple-endpoint.yt-dropdown-menu:nth-child(".concat(value === 'popular' ? 1 : 2, ")");
                                    return [4 /*yield*/, (0, dom_1.waitForElement)(waitSelector)];
                                case 1:
                                    _a.sent();
                                    return [4 /*yield*/, (0, dom_1.waitForElement)(selector)];
                                case 2:
                                    element = _a.sent();
                                    if (element) {
                                        element.click();
                                    }
                                    return [2 /*return*/];
                            }
                        });
                    }); },
                    options: [
                        {
                            label: 'Popular',
                            value: 'popular',
                        },
                        {
                            label: 'Newest',
                            value: 'newest',
                        },
                    ],
                    type: 'dropdown',
                    storageKey: 'persistentCommentSort',
                },
            ],
        },
        {
            title: 'Player',
            groups: [
                {
                    title: 'Hide mini-size button',
                    actions: [
                        {
                            attr: (0, getAttr_1.getAttr)('hide-player-minisize-button'),
                            action: config_1.ElementActions.hide,
                            selectors: [
                                'button.ytp-miniplayer-button.ytp-button',
                            ],
                        },
                    ],
                    storageKey: 'hidePlayerMiniSizePlayerButton',
                },
                {
                    title: 'Hide wide-size button',
                    actions: [
                        {
                            attr: (0, getAttr_1.getAttr)('hide-player-wide-size-button'),
                            action: config_1.ElementActions.hide,
                            selectors: ['button.ytp-size-button.ytp-button'],
                        },
                    ],
                    storageKey: 'hidePlayerWideSizePlayerButton',
                },
                {
                    title: 'Hide subtitles button',
                    actions: [
                        {
                            attr: (0, getAttr_1.getAttr)('hide-player-subtitles-button'),
                            action: config_1.ElementActions.hide,
                            selectors: [
                                'button.ytp-subtitles-button.ytp-button',
                            ],
                        },
                    ],
                    storageKey: 'hidePlayerSubtitlesButton',
                },
                {
                    title: 'Hide autoplay switcher',
                    actions: [
                        {
                            attr: 'hide-player-autoplay',
                            action: config_1.ElementActions.hide,
                            selectors: [
                                '[data-tooltip-target-id=ytp-autonav-toggle-button]',
                            ],
                        },
                    ],
                    storageKey: 'hidePlayerAutoplay',
                },
            ],
        },
        {
            title: 'Shorts',
            groups: [
                {
                    title: 'Shorts auto next',
                    actions: [
                        {
                            urlRegExp: [const_1.UrlRegExps.Shorts],
                            action: config_1.ElementActions.custom,
                            attr: (0, getAttr_1.getAttr)(),
                            selectors: [],
                            onEnable: function () { return __awaiter(void 0, void 0, void 0, function () {
                                var id, root, button, error_1;
                                return __generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0:
                                            _a.trys.push([0, 4, , 5]);
                                            id = '498d5cf9-dbda-4ded-b2a0-0218d1bc833d';
                                            return [4 /*yield*/, (0, dom_1.waitForElement)('#shorts-player video', 3000)];
                                        case 1:
                                            root = _a.sent();
                                            if (!root) {
                                                return [2 /*return*/];
                                            }
                                            (0, dom_1.observeElementChanges)(id, '#shorts-player video', function (element) {
                                                if (element === null || element === void 0 ? void 0 : element.hasAttribute('loop')) {
                                                    element === null || element === void 0 ? void 0 : element.removeAttribute('loop');
                                                }
                                            }, {
                                                childList: false,
                                                subtree: false,
                                                attributes: true,
                                                attributeFilter: ['loop'],
                                                attributeOldValue: false,
                                                characterData: false,
                                                characterDataOldValue: false,
                                            }, root);
                                            return [4 /*yield*/, (0, dom_1.waitForElement)('#shorts-player.ended-mode')];
                                        case 2:
                                            _a.sent();
                                            return [4 /*yield*/, (0, dom_1.waitForElement)('#navigation-button-down button')];
                                        case 3:
                                            button = _a.sent();
                                            if (button) {
                                                button === null || button === void 0 ? void 0 : button.click();
                                            }
                                            return [3 /*break*/, 5];
                                        case 4:
                                            error_1 = _a.sent();
                                            console.error('Element not found or error occurred:', error_1);
                                            return [3 /*break*/, 5];
                                        case 5: return [2 /*return*/];
                                    }
                                });
                            }); },
                        },
                    ],
                    storageKey: 'autoNextShorts',
                },
            ],
        },
        {
            title: 'Description',
            groups: [
                {
                    title: 'Auto-open description',
                    actions: [
                        {
                            attr: '',
                            action: config_1.ElementActions.click,
                            selectors: ['#description #expand'],
                        },
                        // {
                        //     action: ElementActions.hide,
                        //     attr: getAttr('auto-open-description'),
                        //     selectors: ['#description #collapse'],
                        // },
                    ],
                    storageKey: 'autoOpenDescription',
                },
                {
                    title: 'Hide episodes description',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-episodes-description'),
                            selectors: [
                                '#description ytd-horizontal-card-list-renderer:has(#dismissible)',
                            ],
                        },
                    ],
                    storageKey: 'hideEpisodesDescription',
                },
                {
                    title: 'Hide transcript section',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-transcript-section'),
                            selectors: [
                                '#description ytd-video-description-transcript-section-renderer',
                            ],
                        },
                    ],
                    storageKey: 'hideTranscriptSection',
                },
                {
                    title: 'Hide people mentioned',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-people-mentioned'),
                            selectors: [
                                '#description yt-video-attributes-section-view-model',
                            ],
                        },
                    ],
                    storageKey: 'hidePeopleMentioned',
                },
                {
                    title: 'Hide related video',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-related-video-description'),
                            selectors: ['#description #infocards-section'],
                        },
                    ],
                    storageKey: 'hideDescriptionRelatedVideo',
                },
            ],
        },
        {
            title: 'Common',
            groups: [
                {
                    title: 'Hide Live Chat',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-live-chat'),
                            selectors: ['#chat-container'],
                        },
                    ],
                    storageKey: 'hideLiveChat',
                },
                {
                    title: 'Hide "Subscribe" button',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-subscribe-button'),
                            selectors: ['#subscribe-button'],
                        },
                    ],
                    storageKey: 'subscribeButton',
                },
                {
                    title: 'Hide "Sponsor" button',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('hide-sponsor-button'),
                            selectors: ['#sponsor-button'],
                        },
                    ],
                    storageKey: 'hideSponsorButton',
                },
            ],
        },
        {
            title: 'Channel',
            groups: [
                {
                    title: 'Channel trailer',
                    actions: [
                        {
                            urlRegExp: [const_1.UrlRegExps.Channel],
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('channel-trailer'),
                            selectors: [
                                'ytd-two-column-browse-results-renderer ytd-channel-video-player-renderer',
                            ],
                        },
                        {
                            urlRegExp: [const_1.UrlRegExps.Channel],
                            action: config_1.ElementActions.custom,
                            attr: (0, getAttr_1.getAttr)('channel-trailer'),
                            selectors: [],
                            onEnable: function () { return __awaiter(void 0, void 0, void 0, function () {
                                var results, selectors, elements, elements_1, elements_1_1, element, parent_1, nextSibling, error_2;
                                var e_1, _a;
                                return __generator(this, function (_b) {
                                    switch (_b.label) {
                                        case 0:
                                            _b.trys.push([0, 3, , 4]);
                                            return [4 /*yield*/, (0, dom_1.waitForElement)('ytd-two-column-browse-results-renderer ytd-channel-video-player-renderer .html5-video-player:not(.unstarted-mode) video[src]')];
                                        case 1:
                                            _b.sent();
                                            results = [];
                                            selectors = [
                                                'ytd-two-column-browse-results-renderer ytd-channel-video-player-renderer',
                                            ];
                                            return [4 /*yield*/, Promise.all(selectors.map(function (selector, max) {
                                                    return (0, dom_1.waitForElement)(selector, max);
                                                }))];
                                        case 2:
                                            elements = _b.sent();
                                            try {
                                                for (elements_1 = __values(elements), elements_1_1 = elements_1.next(); !elements_1_1.done; elements_1_1 = elements_1.next()) {
                                                    element = elements_1_1.value;
                                                    if (element && element.parentNode) {
                                                        parent_1 = element.parentNode;
                                                        nextSibling = element.nextSibling;
                                                        element.remove();
                                                        results.push({
                                                            element: element,
                                                            parent: parent_1,
                                                            nextSibling: nextSibling,
                                                        });
                                                    }
                                                }
                                            }
                                            catch (e_1_1) { e_1 = { error: e_1_1 }; }
                                            finally {
                                                try {
                                                    if (elements_1_1 && !elements_1_1.done && (_a = elements_1.return)) _a.call(elements_1);
                                                }
                                                finally { if (e_1) throw e_1.error; }
                                            }
                                            return [2 /*return*/, results];
                                        case 3:
                                            error_2 = _b.sent();
                                            return [3 /*break*/, 4];
                                        case 4: return [2 /*return*/];
                                    }
                                });
                            }); },
                            onDisable: function (cachedElements) { return __awaiter(void 0, void 0, void 0, function () {
                                var cachedElements_1, cachedElements_1_1, cached;
                                var e_2, _a;
                                return __generator(this, function (_b) {
                                    try {
                                        try {
                                            for (cachedElements_1 = __values(cachedElements), cachedElements_1_1 = cachedElements_1.next(); !cachedElements_1_1.done; cachedElements_1_1 = cachedElements_1.next()) {
                                                cached = cachedElements_1_1.value;
                                                if (cached.parent && cached.element) {
                                                    cached.parent.insertBefore(cached.element, cached.nextSibling);
                                                }
                                            }
                                        }
                                        catch (e_2_1) { e_2 = { error: e_2_1 }; }
                                        finally {
                                            try {
                                                if (cachedElements_1_1 && !cachedElements_1_1.done && (_a = cachedElements_1.return)) _a.call(cachedElements_1);
                                            }
                                            finally { if (e_2) throw e_2.error; }
                                        }
                                    }
                                    catch (e) {
                                        console.error(e);
                                    }
                                    return [2 /*return*/];
                                });
                            }); },
                        },
                    ],
                    storageKey: 'hideChannelTrailer',
                },
                {
                    title: 'Channel banner',
                    actions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('channel-banner'),
                            selectors: ['#page-header-banner'],
                        },
                    ],
                    storageKey: 'hideChannelBanner',
                },
            ],
        },
    ],
};


/***/ }),

/***/ "./src/shared/const.ts":
/*!*****************************!*\
  !*** ./src/shared/const.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UrlRegExps = exports.BASE_ATTR_PREFIX = void 0;
exports.BASE_ATTR_PREFIX = 'cln-yt-cust';
var UrlRegExps;
(function (UrlRegExps) {
    UrlRegExps["Home"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/?$";
    UrlRegExps["Shorts"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/shorts\\/[^\\/\\?]+";
    UrlRegExps["Watch"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/watch\\?v=[^&]+";
    UrlRegExps["Channel"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+";
    UrlRegExps["ChannelVideos"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/videos\\/?$";
    UrlRegExps["ChannelShorts"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/shorts\\/?$";
    UrlRegExps["ChannelStreams"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/streams\\/?$";
    UrlRegExps["ChannelPlaylists"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/playlists\\/?$";
    UrlRegExps["ChannelCommunity"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/community\\/?$";
    UrlRegExps["ChannelChannels"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/channels\\/?$";
    UrlRegExps["ChannelAbout"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/about\\/?$";
    UrlRegExps["Playlist"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/playlist\\?list=[^&]+";
    UrlRegExps["History"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/feed\\/history\\/?$";
    UrlRegExps["Subscriptions"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/feed\\/subscriptions\\/?$";
    UrlRegExps["Library"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/feed\\/library\\/?$";
    UrlRegExps["Trending"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/feed\\/trending\\/?$";
    UrlRegExps["Music"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/music\\/?$";
    UrlRegExps["Settings"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/account(_.*)?\\/?$";
    UrlRegExps["Search"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/results\\?search_query=.*";
    UrlRegExps["NotSearch"] = "^(?!https:\\/\\/(www\\.)?youtube\\.com\\/results\\?search_query=.*).*";
    UrlRegExps["NotSearchAndChannel"] = "^(?!https:\\/\\/(www\\.)?youtube\\.com\\/(results\\?search_query=.*|(c|channel|@)[^\\/\\?]+)).*";
    UrlRegExps["Notifications"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/notifications\\/?$";
    UrlRegExps["Live"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/live\\/?$";
})(UrlRegExps = exports.UrlRegExps || (exports.UrlRegExps = {}));


/***/ }),

/***/ "./src/shared/storage.ts":
/*!*******************************!*\
  !*** ./src/shared/storage.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, exports) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Storage = void 0;
var Storage = /** @class */ (function () {
    function Storage(defaults) {
        var _this = this;
        this.listeners = [];
        this.settings = __assign({}, defaults);
        chrome.storage.local.get(null, function (data) {
            _this.settings = __assign(__assign({}, defaults), data);
            chrome.storage.local.set(_this.settings);
            _this.notifyListeners();
        });
        chrome.storage.onChanged.addListener(function (changes) {
            // @ts-ignore
            Object.keys(changes).forEach(function (key) {
                var _a;
                _this.settings[key] = (_a = changes[key].newValue) !== null && _a !== void 0 ? _a : defaults[key];
            });
            _this.notifyListeners();
        });
    }
    Storage.prototype.update = function (key, value) {
        var _a;
        this.settings[key] = value;
        chrome.storage.local.set((_a = {}, _a[key] = value, _a));
        this.notifyListeners();
    };
    Storage.prototype.get = function (key) {
        return this.settings[key];
    };
    Storage.prototype.onChange = function (callback) {
        this.listeners.push(callback);
    };
    Storage.prototype.notifyListeners = function () {
        this.listeners.forEach(function (cb) { return cb(); });
    };
    return Storage;
}());
exports.Storage = Storage;


/***/ }),

/***/ "./src/shared/storage/config.ts":
/*!**************************************!*\
  !*** ./src/shared/storage/config.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DEFAULT_STORAGE = void 0;
exports.DEFAULT_STORAGE = {
    isEnabled: true,
    hideShorts: { enabled: false },
    hideChannelBanner: { enabled: false },
    hideTranscriptSection: { enabled: false },
    adsFeedVideo: { enabled: false },
    defaultMusicPlaybackSpeed: { enabled: false },
    persistentCommentSort: { enabled: false, value: 'popular' },
    persistentQuality: { enabled: false, value: '1080' },
    persistentPlaybackSpeed: { enabled: false, value: '1.00' },
    adsYoutubeBanner: { enabled: false },
    adsSearchResults: { enabled: false },
    hideChannelTrailer: { enabled: false },
    autoNextShorts: { enabled: false },
    hideJams: { enabled: false },
    searchMode: { enabled: false },
    hideSearchTags: { enabled: false },
    hidePlayerSubtitlesButton: { enabled: false },
    hidePeopleMentioned: { enabled: false },
    hideDescriptionRelatedVideo: { enabled: false },
    hideSponsorVideo: { enabled: false },
    rightCommentMode: { enabled: false },
    hideEpisodesDescription: { enabled: false },
    hideCreateVideo: { enabled: false },
    voiceButtonInSearch: { enabled: false },
    hidePlayerWideSizePlayerButton: { enabled: false },
    hidePlayerMiniSizePlayerButton: { enabled: false },
    virtualKeyboard: { enabled: false },
    subscribeButton: { enabled: false },
    hideSponsorButton: { enabled: false },
    notificationButton: { enabled: false },
    relatedVideos: { enabled: false, maxVideo: 5 },
    hideLiveChat: { enabled: false },
    disableAutoplay: { enabled: false },
    commentsRightMode: { enabled: false },
    hideYourMovies: { enabled: false },
    hideNewsSection: { enabled: false },
    hidePlayerAutoplay: { enabled: false },
    autoOpenDescription: { enabled: false },
    hideMenuShorts: { enabled: false },
    hideMenuPlaylists: { enabled: false },
    hideMenuYourVideo: { enabled: false },
    hideMenuHistory: { enabled: false },
    hideMenuWatchLater: { enabled: false },
    hideMenuLikedVideos: { enabled: false },
    hideMenuSubscriptionsList: { enabled: false },
    hideMenuExploreMusic: { enabled: false },
    hideMenuExploreGaming: { enabled: false },
    hideMenuExploreSports: { enabled: false },
    hideMenuExploreNews: { enabled: false },
    hideMenuExploreTrending: { enabled: false },
    hideMenuMorePremium: { enabled: false },
    hideMenuMoreKids: { enabled: false },
    hideMenuMoreMusic: { enabled: false },
    hideMenuMoreStudio: { enabled: false },
    dailyTimeLimit: { enabled: false, valueInMinutes: String(60 * 2) },
    spentTimeToday: { enabled: false, value: String(0) },
};


/***/ }),

/***/ "./src/shared/types/config.ts":
/*!************************************!*\
  !*** ./src/shared/types/config.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ElementActions = void 0;
var ElementActions;
(function (ElementActions) {
    ElementActions["hide"] = "hide";
    ElementActions["click"] = "click";
    ElementActions["custom"] = "custom";
    ElementActions["dropdown"] = "dropdown";
    ElementActions["customStyles"] = "customStyles";
    ElementActions["component"] = "component";
})(ElementActions = exports.ElementActions || (exports.ElementActions = {}));


/***/ }),

/***/ "./src/shared/utils/browser.ts":
/*!*************************************!*\
  !*** ./src/shared/utils/browser.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.showElement = exports.hideElement = exports.clickElement = exports.waitForDocumentReady = exports.isOpera = void 0;
var isOpera = function () { return typeof (globalThis === null || globalThis === void 0 ? void 0 : globalThis.opr) !== 'undefined'; };
exports.isOpera = isOpera;
var waitForDocumentReady = function () {
    return new Promise(function (resolve) {
        if (document.readyState === 'complete') {
            resolve();
        }
        else {
            window.addEventListener('load', function () { return resolve(); }, { once: true });
        }
    });
};
exports.waitForDocumentReady = waitForDocumentReady;
var clickElement = function (selector) { var _a; return (_a = document.querySelector(selector)) === null || _a === void 0 ? void 0 : _a.click(); };
exports.clickElement = clickElement;
var hideElement = function (selector) {
    var el = document.querySelector(selector);
    if (el) {
        el.style.setProperty('opacity', '0', 'important');
    }
};
exports.hideElement = hideElement;
var showElement = function (selector) {
    var el = document.querySelector(selector);
    if (el) {
        el.style.removeProperty('opacity');
    }
};
exports.showElement = showElement;


/***/ }),

/***/ "./src/shared/utils/cookies.ts":
/*!*************************************!*\
  !*** ./src/shared/utils/cookies.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.cookie = void 0;
exports.cookie = {
    set: function (name, value, days, path, domain) {
        if (path === void 0) { path = '/'; }
        if (domain === void 0) { domain = '.youtube.com'; }
        var cookieStr = "".concat(encodeURIComponent(name), "=").concat(encodeURIComponent(value), "; path=").concat(path);
        if (domain) {
            cookieStr += "; domain=".concat(domain);
        }
        if (typeof days === 'number') {
            var expires = new Date(Date.now() + days * 864e5).toUTCString();
            cookieStr += "; expires=".concat(expires);
        }
        document.cookie = cookieStr;
    },
    get: function (name) {
        var _a;
        return ((_a = document.cookie
            .split('; ')
            .find(function (row) { return row.startsWith("".concat(encodeURIComponent(name), "=")); })) === null || _a === void 0 ? void 0 : _a.split('=')[1]) || null;
    },
    remove: function (name, path) {
        if (path === void 0) { path = '/'; }
        document.cookie = "".concat(encodeURIComponent(name), "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=").concat(path);
    },
};


/***/ }),

/***/ "./src/shared/utils/dom.ts":
/*!*********************************!*\
  !*** ./src/shared/utils/dom.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.observeElementChanges = exports.waitForElement = void 0;
var waitForElement = function (selector, maxTimeout, root) {
    if (maxTimeout === void 0) { maxTimeout = 0; }
    if (root === void 0) { root = document.documentElement; }
    return new Promise(function (resolve) {
        var existing = document.querySelector(selector);
        if (existing)
            return resolve(existing);
        var observer = new MutationObserver(function () {
            var element = document.querySelector(selector);
            if (element) {
                observer.disconnect();
                if (timeoutId)
                    clearTimeout(timeoutId);
                resolve(element);
            }
        });
        observer.observe(root, {
            childList: true,
            subtree: true,
        });
        var timeoutId = null;
        if (maxTimeout > 0) {
            timeoutId = setTimeout(function () {
                observer.disconnect();
                resolve(null);
            }, maxTimeout);
        }
    });
};
exports.waitForElement = waitForElement;
var observeElementChanges = function (id, selector, callback, options, root) {
    if (options === void 0) { options = {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true,
    }; }
    if (root === void 0) { root = document.documentElement; }
    if (!window.__elementObservers__) {
        window.__elementObservers__ = {};
    }
    if (window.__elementObservers__[id]) {
        window.__elementObservers__[id].disconnect();
        delete window.__elementObservers__[id];
    }
    var checkAndCallback = function () {
        var element = document.querySelector(selector);
        if (element)
            callback(element);
    };
    checkAndCallback();
    var observer = new MutationObserver(function () {
        checkAndCallback();
    });
    observer.observe(root, options);
    window.__elementObservers__[id] = observer;
};
exports.observeElementChanges = observeElementChanges;


/***/ }),

/***/ "./src/shared/utils/format.tsx":
/*!*************************************!*\
  !*** ./src/shared/utils/format.tsx ***!
  \*************************************/
/***/ (function(__unused_webpack_module, exports) {


var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.formatTime = exports.formatNumber = void 0;
var formatNumber = function (value, exp) {
    if (exp === void 0) { exp = false; }
    if (isNaN(Number(value)))
        return value.toString();
    var num = Number(value);
    if (exp && Math.abs(num) >= 1e17) {
        return num.toExponential(10);
    }
    if (Math.abs(num) >= 1e14) {
        return num.toExponential(10);
    }
    var originalStr = typeof value === 'string' ? value : value.toString();
    originalStr = originalStr.replace(',', '.');
    var hasDot = originalStr.includes('.');
    var _a = __read(originalStr.split('.'), 2), integerPartRaw = _a[0], fractionalPart = _a[1];
    if (fractionalPart === undefined)
        fractionalPart = '';
    var sign = '';
    if (integerPartRaw === '' ||
        integerPartRaw === '-' ||
        integerPartRaw === '+') {
        if (integerPartRaw === '-' || integerPartRaw === '+') {
            sign = integerPartRaw;
        }
        integerPartRaw = '0';
    }
    var formattedInteger = new Intl.NumberFormat('ru-RU', {
        maximumFractionDigits: 19,
        useGrouping: true,
    }).format(Number(integerPartRaw));
    formattedInteger = formattedInteger.replace(/\u00A0/g, ' ');
    if (hasDot) {
        return "".concat(formattedInteger, ".").concat(fractionalPart);
    }
    return formattedInteger;
};
exports.formatNumber = formatNumber;
var formatTime = function (minutes) {
    var h = Math.floor(minutes / 60);
    var m = minutes % 60;
    var parts = [];
    if (h > 0)
        parts.push("".concat(h, "h"));
    if (m > 0 || h === 0)
        parts.push("".concat(m, "m"));
    return parts.join(' ');
};
exports.formatTime = formatTime;


/***/ }),

/***/ "./src/shared/utils/getAttr.ts":
/*!*************************************!*\
  !*** ./src/shared/utils/getAttr.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getAttr = void 0;
var const_1 = __webpack_require__(/*! src/shared/const */ "./src/shared/const.ts");
var generateId = function () {
    var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var result = '';
    for (var i = 0; i < 8; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
};
var getAttr = function (attr) {
    return "".concat(const_1.BASE_ATTR_PREFIX, "-").concat(attr ? attr : generateId());
};
exports.getAttr = getAttr;


/***/ }),

/***/ "./src/shared/utils/yt.ts":
/*!********************************!*\
  !*** ./src/shared/utils/yt.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.setQualityVideo = exports.setPlaybackSpeed = void 0;
var setPlaybackSpeed = function (value) {
    var movieContainer = document.querySelector('#movie_player');
    if (movieContainer) {
        var player = movieContainer.getElementsByTagName('video')[0];
        player.playbackRate = Number(Number(value).toFixed(2));
    }
    var newLocalStorageValue = {
        creation: Date.now(),
        data: value,
    };
    if (window.sessionStorage) {
        window.sessionStorage.setItem('yt-player-playback-rate', JSON.stringify(newLocalStorageValue));
    }
};
exports.setPlaybackSpeed = setPlaybackSpeed;
var setQualityVideo = function (value) {
    var newLocalStorageValue = {
        creation: Date.now(),
        data: JSON.stringify({
            quality: value,
            previousQuality: value,
        }),
        expiration: Date.now() + 24 * 60 * 60 * 1000,
    };
    if (window.localStorage) {
        window.localStorage.setItem('yt-player-quality', JSON.stringify(newLocalStorageValue));
    }
};
exports.setQualityVideo = setQualityVideo;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/content/index.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=content.js.map