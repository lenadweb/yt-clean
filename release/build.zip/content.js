/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/content/index.ts":
/*!******************************!*\
  !*** ./src/content/index.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var config_1 = __webpack_require__(/*! src/shared/types/config */ "./src/shared/types/config.ts");
var config_2 = __webpack_require__(/*! src/shared/storage/config */ "./src/shared/storage/config.ts");
var config_3 = __webpack_require__(/*! src/shared/config */ "./src/shared/config/index.ts");
var getAttr_1 = __webpack_require__(/*! src/shared/utils/getAttr */ "./src/shared/utils/getAttr.ts");
var storage_1 = __webpack_require__(/*! ./storage */ "./src/content/storage.ts");
var Content = /** @class */ (function () {
    function Content(config, defaults) {
        var _this = this;
        this.elementCache = new Map();
        this.config = config;
        this.storage = new storage_1.Storage(defaults);
        this.currentUrl = window.location.href;
        this.observeUrlChanges();
        this.storage.onChange(function () { return _this.processActions(); });
        this.init();
    }
    Content.prototype.observeUrlChanges = function () {
        var _this = this;
        var observer = new MutationObserver(function () {
            if (window.location.href !== _this.currentUrl) {
                _this.currentUrl = window.location.href;
                _this.processActions();
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
    };
    Content.prototype.init = function () {
        this.processActions();
    };
    Content.prototype.processActions = function () {
        var _this = this;
        var enabledActions = this.getEnabledActions();
        enabledActions.forEach(function (item) {
            var e_1, _a;
            var status = item.status, actions = item.actions, group = item.group;
            var _loop_1 = function (act) {
                var isTargetUrl = act.urlRegExp
                    ? act.urlRegExp.some(function (regexp) {
                        return new RegExp(regexp).test(_this.currentUrl);
                    })
                    : true;
                if (status.enabled && isTargetUrl && act.attr) {
                    if ((0, getAttr_1.getAttr)('more-from-yt-group') == act.attr) {
                        console.log(act);
                    }
                    document.body.setAttribute(act.attr, 'true');
                }
                else if (act.attr) {
                    document.body.removeAttribute(act.attr);
                }
                if (act.action === config_1.ElementActions.click && status.enabled) {
                    act.selectors.forEach(function (selector) {
                        var element = document.querySelector(selector);
                        if (element)
                            element.click();
                    });
                }
                if (act.action === config_1.ElementActions.custom &&
                    status.enabled &&
                    act.onEnable) {
                    act.onEnable().then(function (result) {
                        console.log(result);
                        if (result && act.attr) {
                            _this.elementCache.set(act.attr, result);
                        }
                    });
                }
                if (act.action === config_1.ElementActions.custom &&
                    !status.enabled &&
                    act.onDisable &&
                    act.attr) {
                    var cached = _this.elementCache.get(act.attr);
                    if (cached) {
                        act.onDisable(cached);
                        _this.elementCache.delete(act.attr);
                    }
                }
            };
            try {
                for (var actions_1 = __values(actions), actions_1_1 = actions_1.next(); !actions_1_1.done; actions_1_1 = actions_1.next()) {
                    var act = actions_1_1.value;
                    _loop_1(act);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (actions_1_1 && !actions_1_1.done && (_a = actions_1.return)) _a.call(actions_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            if (status.enabled && (group === null || group === void 0 ? void 0 : group.onChange)) {
                group.onChange(status.value);
            }
            if (!status.enabled && (group === null || group === void 0 ? void 0 : group.onChange)) {
                group.onChange('disabled');
            }
        });
    };
    Content.prototype.getEnabledActions = function () {
        var domActions = this.config.domActions;
        var settings = this.storage.settings;
        var isEnabled = settings.isEnabled;
        var collectActions = function (blocks) {
            return blocks.flatMap(function (block) { return block.groups || []; });
        };
        var extractEnabledActions = function (groups) {
            return groups.map(function (group) {
                var _a, _b;
                return ({
                    status: {
                        enabled: (isEnabled && ((_a = settings[group.storageKey]) === null || _a === void 0 ? void 0 : _a.enabled)) ||
                            false,
                        value: (_b = settings[group.storageKey]) === null || _b === void 0 ? void 0 : _b.value,
                    },
                    actions: group.actions,
                    group: __assign(__assign({}, group), { actions: null }),
                });
            });
        };
        var domGroups = collectActions(domActions.flatMap(function (action) { return action.settings || []; }));
        var enabledActions = extractEnabledActions(domGroups);
        var fullEnabledGroupAction = domActions
            .flatMap(function (action) { return action.settings || []; })
            .map(function (action) {
            var allActionsIsEnabled = action.groups
                .map(function (item) { var _a; return !!((_a = settings[item.storageKey]) === null || _a === void 0 ? void 0 : _a.enabled); })
                .every(Boolean);
            if (action.onFullGroupEnabledActions) {
                console.log({ allActionsIsEnabled: allActionsIsEnabled });
            }
            return action.onFullGroupEnabledActions
                ? [
                    {
                        status: {
                            enabled: allActionsIsEnabled,
                            value: null,
                        },
                        actions: action.onFullGroupEnabledActions,
                        group: null,
                    },
                ]
                : [];
        })
            .flatMap(function (value) { return value; });
        var result = __spreadArray(__spreadArray([], __read(enabledActions), false), __read(fullEnabledGroupAction), false);
        console.log(result);
        return result;
    };
    return Content;
}());
new Content(config_3.CONFIG, config_2.DEFAULT_STORAGE);


/***/ }),

/***/ "./src/content/storage.ts":
/*!********************************!*\
  !*** ./src/content/storage.ts ***!
  \********************************/
/***/ (function(__unused_webpack_module, exports) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Storage = void 0;
var Storage = /** @class */ (function () {
    function Storage(defaults) {
        var _this = this;
        this.listeners = [];
        this.settings = __assign({}, defaults);
        chrome.storage.local.get(null, function (data) {
            _this.settings = __assign(__assign({}, defaults), data);
            chrome.storage.local.set(_this.settings);
            _this.notifyListeners();
        });
        chrome.storage.onChanged.addListener(function (changes) {
            // @ts-ignore
            Object.keys(changes).forEach(function (key) {
                var _a;
                _this.settings[key] = (_a = changes[key].newValue) !== null && _a !== void 0 ? _a : defaults[key];
            });
            _this.notifyListeners();
        });
    }
    Storage.prototype.update = function (key, value) {
        var _a;
        this.settings[key] = value;
        chrome.storage.local.set((_a = {}, _a[key] = value, _a));
        this.notifyListeners();
    };
    Storage.prototype.get = function (key) {
        return this.settings[key];
    };
    Storage.prototype.onChange = function (callback) {
        this.listeners.push(callback);
    };
    Storage.prototype.notifyListeners = function () {
        this.listeners.forEach(function (cb) { return cb(); });
    };
    return Storage;
}());
exports.Storage = Storage;


/***/ }),

/***/ "./src/shared/config/index.ts":
/*!************************************!*\
  !*** ./src/shared/config/index.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CONFIG = void 0;
var const_1 = __webpack_require__(/*! src/shared/const */ "./src/shared/const.ts");
var config_1 = __webpack_require__(/*! src/shared/types/config */ "./src/shared/types/config.ts");
var getAttr_1 = __webpack_require__(/*! src/shared/utils/getAttr */ "./src/shared/utils/getAttr.ts");
var dom_1 = __webpack_require__(/*! src/shared/utils/dom */ "./src/shared/utils/dom.ts");
exports.CONFIG = {
    domActions: [
        {
            title: 'Sidebar & Navigation',
            settings: [
                {
                    title: 'Main menu',
                    groups: [
                        {
                            title: 'Shorts',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-shorts'),
                                    selectors: [
                                        'ytd-mini-guide-entry-renderer[aria-label=Shorts]',
                                        '#sections #items > ytd-guide-entry-renderer:has([title=Shorts])',
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuShorts',
                        },
                    ],
                    withoutSwitch: true,
                },
                {
                    title: 'You',
                    // #sections > ytd-guide-section-renderer:has([href*='feed/trending'])
                    groups: [
                        {
                            title: 'History',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-history'),
                                    selectors: [
                                        '#section-items ytd-guide-entry-renderer:has([href="/feed/history"])',
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuHistory',
                        },
                        {
                            title: 'Playlists',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-playlists'),
                                    selectors: [
                                        '#section-items ytd-guide-entry-renderer:has([href="/feed/playlists"])',
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuPlaylists',
                        },
                        {
                            title: 'Your video',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-your-video'),
                                    selectors: [
                                        '#section-items ytd-guide-entry-renderer:has([href*="studio.youtube"])',
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuYourVideo',
                        },
                        {
                            title: 'Watch later',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-watch-later'),
                                    selectors: [
                                        '#section-items ytd-guide-entry-renderer:has([href="/playlist?list=WL"])',
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuWatchLater',
                        },
                        {
                            title: 'Liked videos',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-liked-videos'),
                                    selectors: [
                                        '#section-items ytd-guide-entry-renderer:has([href="/playlist?list=LL"])',
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuLikedVideos',
                        },
                        {
                            title: 'Your Movies',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-your-movies'),
                                    selectors: [
                                        '#section-items ytd-guide-entry-renderer:has([href*="/feed/storefront"])',
                                    ],
                                },
                            ],
                            storageKey: 'hideYourMovies',
                        },
                    ],
                    onFullGroupEnabledActions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('full-group-you'),
                            selectors: [
                                '#sections ytd-guide-collapsible-section-entry-renderer:has([href="/feed/history"])',
                            ],
                        },
                    ],
                },
                {
                    title: 'Subscriptions list',
                    groups: [
                        {
                            title: 'Subscriptions list',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-subscriptions-list'),
                                    selectors: [
                                        "#sections ytd-guide-section-renderer:has([href*='@'])",
                                        "ytd-mini-guide-renderer ytd-mini-guide-entry-renderer:has([href='/feed/subscriptions'])",
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuSubscriptionsList',
                        },
                    ],
                    withoutCheckboxes: true,
                },
                {
                    title: 'Explore',
                    groups: [
                        {
                            title: 'Trending',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-explore-trending'),
                                    selectors: [
                                        "#sections ytd-guide-entry-renderer:has([href*='feed/trending'])",
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuExploreTrending',
                        },
                        {
                            title: 'Music',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-explore-music'),
                                    selectors: [
                                        "#sections ytd-guide-entry-renderer:has([href*='channel/UC-9'])",
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuExploreMusic',
                        },
                        {
                            title: 'Gaming',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-explore-gaming'),
                                    selectors: [
                                        "#sections ytd-guide-entry-renderer:has([href='/gaming'])",
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuExploreGaming',
                        },
                        {
                            title: 'News',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-explore-news'),
                                    selectors: [
                                        "#sections ytd-guide-entry-renderer:has([href*='UCYfdidRxbB8Qhf0Nx7ioOYw'])",
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuExploreNews',
                        },
                        {
                            title: 'Sports',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-explore-sports'),
                                    selectors: [
                                        "#sections ytd-guide-entry-renderer:has([href*='UCEgdi0XIXXZ-qJOFPf4JSKw'])",
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuExploreSports',
                        },
                    ],
                    onFullGroupEnabledActions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('explore-group'),
                            selectors: [
                                "#sections ytd-guide-section-renderer:has([href*='feed/trending'])",
                            ],
                        },
                    ],
                },
                {
                    title: 'More from YouTube',
                    groups: [
                        {
                            title: 'YouTube Premium',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-more-premium'),
                                    selectors: [
                                        "#sections #items ytd-guide-entry-renderer:has([href='/premium'])",
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuMorePremium',
                        },
                        {
                            title: 'YouTube Music',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-more-music'),
                                    selectors: [
                                        "#sections #items ytd-guide-entry-renderer:has([href='https://music.youtube.com/'])",
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuMoreMusic',
                        },
                        {
                            title: 'YouTube Kids',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-more-kids'),
                                    selectors: [
                                        "#sections #items ytd-guide-entry-renderer:has([href*='youtubekids.com'])",
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuMoreKids',
                        },
                        {
                            title: 'YouTube Studio',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-menu-more-studio'),
                                    selectors: [
                                        "#sections #items ytd-guide-entry-renderer:has([href*='studio.youtube.com'])",
                                    ],
                                },
                            ],
                            storageKey: 'hideMenuMoreStudio',
                        },
                    ],
                    onFullGroupEnabledActions: [
                        {
                            action: config_1.ElementActions.hide,
                            attr: (0, getAttr_1.getAttr)('more-from-yt-group'),
                            selectors: [
                                "#sections ytd-guide-section-renderer:has([href='https://music.youtube.com/'])",
                            ],
                        },
                    ],
                },
            ],
        },
        {
            title: 'Top Panel',
            settings: [
                {
                    title: 'Search Bar',
                    groups: [
                        {
                            title: 'Voice search button',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-voice-search'),
                                    selectors: ['#voice-search-button'],
                                },
                            ],
                            storageKey: 'voiceButtonInSearch',
                        },
                        {
                            title: 'Virtual keyboard button',
                            actions: [
                                {
                                    title: 'Virtual keyboard button',
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-virtual-keyboard'),
                                    selectors: [
                                        '.ytSearchboxComponentYtdTextInputAssistantWrapper',
                                    ],
                                },
                            ],
                            storageKey: 'virtualKeyboard',
                        },
                        {
                            title: 'Search tags',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-search-tags'),
                                    urlRegExp: [const_1.UrlRegExps.Home],
                                    selectors: [
                                        '.ytd-feed-filter-chip-bar-renderer',
                                        '#header.ytd-rich-grid-renderer',
                                        'yt-related-chip-cloud-renderer',
                                    ],
                                },
                            ],
                            storageKey: 'hideSearchTags',
                        },
                    ],
                },
                {
                    title: 'Actions & user',
                    groups: [
                        {
                            title: 'Upload button',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-create-video'),
                                    selectors: [
                                        '#buttons .ytd-masthead:first-child',
                                    ],
                                },
                            ],
                            storageKey: 'hideCreateVideo',
                        },
                        {
                            title: 'Notifications',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-notification-button'),
                                    selectors: [
                                        'ytd-notification-topbar-button-renderer.ytd-masthead',
                                    ],
                                },
                            ],
                            storageKey: 'notificationButton',
                        },
                    ],
                },
            ],
        },
        {
            title: 'Feed & Recommendations',
            settings: [
                {
                    title: 'Content blocks',
                    groups: [
                        {
                            title: 'Shorts sections',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-shorts'),
                                    selectors: [
                                        'ytd-rich-section-renderer:has([is-shorts])',
                                        'ytd-reel-shelf-renderer:has(#left-arrow)',
                                        'ytd-reel-shelf-renderer.ytd-watch-next-secondary-results-renderer',
                                        'ytd-reel-shelf-renderer',
                                    ],
                                },
                            ],
                            storageKey: 'hideShorts',
                        },
                        {
                            title: 'Explore & News',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-news-section'),
                                    selectors: [
                                        'ytd-rich-section-renderer:has(#rich-shelf-header):not(:has(.shortsLockupViewModelHostThumbnail))',
                                    ],
                                },
                            ],
                            storageKey: 'hideNewsSection',
                        },
                        {
                            title: 'Mixes & Playlists',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-jams'),
                                    selectors: [
                                        'ytd-rich-item-renderer:has(.yt-lockup-view-model-wiz--collection-stack-2)',
                                    ],
                                },
                            ],
                            storageKey: 'hideJams',
                        },
                    ],
                },
            ],
        },
        {
            title: 'Video page',
            settings: [
                {
                    title: 'Common',
                    groups: [
                        {
                            title: 'Hide Live Chat',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-live-chat'),
                                    selectors: ['#chat-container'],
                                },
                            ],
                            storageKey: 'hideLiveChat',
                        },
                        {
                            title: 'Hide "Subscribe" button',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-subscribe-button'),
                                    selectors: ['#subscribe-button'],
                                },
                            ],
                            storageKey: 'subscribeButton',
                        },
                        {
                            title: 'Hide "Sponsor" button',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-sponsor-button'),
                                    selectors: ['#sponsor-button'],
                                },
                            ],
                            storageKey: 'hideSponsorButton',
                        },
                        {
                            title: 'Right comment mode',
                            actions: [
                                {
                                    urlRegExp: [const_1.UrlRegExps.Watch],
                                    attr: (0, getAttr_1.getAttr)(),
                                    action: config_1.ElementActions.custom,
                                    selectors: [],
                                },
                            ],
                            storageKey: 'rightCommentMode',
                        },
                    ],
                },
                {
                    title: 'Persistent playback speed',
                    groups: [
                        {
                            actions: [
                                {
                                    attr: (0, getAttr_1.getAttr)(),
                                    action: config_1.ElementActions.dropdown,
                                    selectors: [],
                                },
                            ],
                            onChange: function (value) {
                                if (value === 'disabled') {
                                    value = '1.00';
                                }
                                var movieContainer = document.querySelector('#movie_player');
                                if (movieContainer) {
                                    var player = movieContainer.getElementsByTagName('video')[0];
                                    player.playbackRate = Number(Number(value).toFixed(2));
                                }
                                var newLocalStorageValue = {
                                    creation: Date.now(),
                                    data: value,
                                };
                                if (window.sessionStorage) {
                                    window.sessionStorage.setItem('yt-player-playback-rate', JSON.stringify(newLocalStorageValue));
                                }
                            },
                            options: [
                                {
                                    label: '0.5x',
                                    value: '0.50',
                                },
                                {
                                    label: '0.75x',
                                    value: '0.75',
                                },
                                {
                                    label: '1x',
                                    value: '1.00',
                                },
                                {
                                    label: '1.25x',
                                    value: '1.25',
                                },
                                {
                                    label: '1.5x',
                                    value: '1.50',
                                },
                                {
                                    label: '1.75x',
                                    value: '1.75',
                                },
                                {
                                    label: '2x',
                                    value: '2.25',
                                },
                                {
                                    label: '2.5x',
                                    value: '2.50',
                                },
                                {
                                    label: '2.75x',
                                    value: '2.75',
                                },
                                {
                                    label: '3x',
                                    value: '3.00',
                                },
                            ],
                            type: 'dropdown',
                            storageKey: 'persistentPlaybackSpeed',
                        },
                    ],
                },
                {
                    title: 'Persistent video quality',
                    groups: [
                        {
                            actions: [
                                {
                                    attr: (0, getAttr_1.getAttr)(),
                                    action: config_1.ElementActions.dropdown,
                                    selectors: [],
                                },
                            ],
                            onChange: function (value) { return __awaiter(void 0, void 0, void 0, function () {
                                var newLocalStorageValue;
                                return __generator(this, function (_a) {
                                    // todo:
                                    if (value === 'disabled') {
                                        value = '1080';
                                    }
                                    newLocalStorageValue = {
                                        creation: Date.now(),
                                        data: JSON.stringify({
                                            quality: value,
                                            previousQuality: value,
                                        }),
                                        expiration: Date.now() + 24 * 60 * 60 * 1000,
                                    };
                                    if (window.localStorage) {
                                        window.localStorage.setItem('yt-player-quality', JSON.stringify(newLocalStorageValue));
                                    }
                                    return [2 /*return*/];
                                });
                            }); },
                            options: [
                                {
                                    label: '2160p',
                                    value: '2160',
                                },
                                {
                                    label: '1440p',
                                    value: '1440',
                                },
                                {
                                    label: '1080p',
                                    value: '1080',
                                },
                                {
                                    label: '720p',
                                    value: '720',
                                },
                                {
                                    label: '480p',
                                    value: '480',
                                },
                                {
                                    label: '360p',
                                    value: '360',
                                },
                                {
                                    label: '240p',
                                    value: '240',
                                },
                                {
                                    label: '144p',
                                    value: '144',
                                },
                            ],
                            type: 'dropdown',
                            storageKey: 'persistentQuality',
                        },
                    ],
                },
                {
                    title: 'Persistent comment sort',
                    groups: [
                        {
                            actions: [
                                {
                                    urlRegExp: [const_1.UrlRegExps.Watch],
                                    attr: (0, getAttr_1.getAttr)(),
                                    action: config_1.ElementActions.dropdown,
                                    selectors: [],
                                },
                            ],
                            onChange: function (value) { return __awaiter(void 0, void 0, void 0, function () {
                                var waitSelector, selector, element;
                                return __generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0:
                                            if (value === 'disabled')
                                                return [2 /*return*/];
                                            waitSelector = 'ytd-comments#comments ytd-item-section-renderer:not([continuation-is-reloading])';
                                            selector = "#sort-menu tp-yt-paper-menu-button tp-yt-iron-dropdown a.yt-simple-endpoint.yt-dropdown-menu:nth-child(".concat(value === 'popular' ? 1 : 2, ")");
                                            return [4 /*yield*/, (0, dom_1.waitForElement)(waitSelector)];
                                        case 1:
                                            _a.sent();
                                            return [4 /*yield*/, (0, dom_1.waitForElement)(selector)];
                                        case 2:
                                            element = _a.sent();
                                            if (element) {
                                                element.click();
                                            }
                                            return [2 /*return*/];
                                    }
                                });
                            }); },
                            options: [
                                {
                                    label: 'Popular',
                                    value: 'popular',
                                },
                                {
                                    label: 'Newest',
                                    value: 'newest',
                                },
                            ],
                            type: 'dropdown',
                            storageKey: 'persistentCommentSort',
                        },
                    ],
                },
                {
                    title: 'Player',
                    groups: [
                        {
                            title: 'Hide mini-size button',
                            actions: [
                                {
                                    attr: (0, getAttr_1.getAttr)('hide-player-minisize-button'),
                                    action: config_1.ElementActions.hide,
                                    selectors: [
                                        'button.ytp-miniplayer-button.ytp-button',
                                    ],
                                },
                            ],
                            storageKey: 'hidePlayerMiniSizePlayerButton',
                        },
                        {
                            title: 'Hide wide-size button',
                            actions: [
                                {
                                    attr: (0, getAttr_1.getAttr)('hide-player-wide-size-button'),
                                    action: config_1.ElementActions.hide,
                                    selectors: [
                                        'button.ytp-size-button.ytp-button',
                                    ],
                                },
                            ],
                            storageKey: 'hidePlayerWideSizePlayerButton',
                        },
                        {
                            title: 'Hide subtitles button',
                            actions: [
                                {
                                    attr: (0, getAttr_1.getAttr)('hide-player-subtitles-button'),
                                    action: config_1.ElementActions.hide,
                                    selectors: [
                                        'button.ytp-subtitles-button.ytp-button',
                                    ],
                                },
                            ],
                            storageKey: 'hidePlayerSubtitlesButton',
                        },
                        {
                            title: 'Hide autoplay switcher',
                            actions: [
                                {
                                    attr: 'hide-player-autoplay',
                                    action: config_1.ElementActions.hide,
                                    selectors: [
                                        '[data-tooltip-target-id=ytp-autonav-toggle-button]',
                                    ],
                                },
                            ],
                            storageKey: 'hidePlayerAutoplay',
                        },
                    ],
                },
                {
                    title: 'Description',
                    groups: [
                        {
                            title: 'Auto-open description',
                            actions: [
                                {
                                    attr: '',
                                    action: config_1.ElementActions.click,
                                    selectors: ['#description #expand'],
                                },
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('auto-open-description'),
                                    selectors: ['#description #collapse'],
                                },
                            ],
                            storageKey: 'autoOpenDescription',
                        },
                        {
                            title: 'Hide episodes description',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-episodes-description'),
                                    selectors: [
                                        '#description ytd-horizontal-card-list-renderer:has(#dismissible)',
                                    ],
                                },
                            ],
                            storageKey: 'hideEpisodesDescription',
                        },
                        {
                            title: 'Hide transcript section',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-transcript-section'),
                                    selectors: [
                                        '#description ytd-video-description-transcript-section-renderer',
                                    ],
                                },
                            ],
                            storageKey: 'hideTranscriptSection',
                        },
                        {
                            title: 'Hide people mentioned',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-people-mentioned'),
                                    selectors: [
                                        '#description yt-video-attributes-section-view-model',
                                    ],
                                },
                            ],
                            storageKey: 'hidePeopleMentioned',
                        },
                        {
                            title: 'Hide related video',
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-related-video-description'),
                                    selectors: [
                                        '#description #infocards-section',
                                    ],
                                },
                            ],
                            storageKey: 'hideDescriptionRelatedVideo',
                        },
                    ],
                },
                {
                    title: 'Sponsored feed video',
                    groups: [
                        {
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('sponsored-feed-video'),
                                    selectors: [
                                        'ytd-rich-item-renderer:has(ytd-ad-slot-renderer)',
                                    ],
                                },
                            ],
                            storageKey: 'adsFeedVideo',
                        },
                    ],
                    withoutCheckboxes: true,
                },
            ],
        },
        {
            title: 'Channel page',
            settings: [
                {
                    title: 'Channel banner',
                    groups: [
                        {
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('channel-banner'),
                                    selectors: ['#page-header-banner'],
                                },
                            ],
                            storageKey: 'hideChannelBanner',
                        },
                    ],
                    withoutCheckboxes: true,
                },
                {
                    title: 'Channel trailer',
                    groups: [
                        {
                            actions: [
                                {
                                    urlRegExp: [const_1.UrlRegExps.Channel],
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('channel-trailer'),
                                    selectors: [
                                        'ytd-two-column-browse-results-renderer ytd-channel-video-player-renderer',
                                    ],
                                },
                                {
                                    urlRegExp: [const_1.UrlRegExps.Channel],
                                    action: config_1.ElementActions.custom,
                                    attr: (0, getAttr_1.getAttr)('channel-trailer'),
                                    selectors: [],
                                    onEnable: function () { return __awaiter(void 0, void 0, void 0, function () {
                                        var results, selectors, elements, elements_1, elements_1_1, element, parent_1, nextSibling, error_1;
                                        var e_1, _a;
                                        return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0:
                                                    _b.trys.push([0, 3, , 4]);
                                                    return [4 /*yield*/, (0, dom_1.waitForElement)('ytd-two-column-browse-results-renderer ytd-channel-video-player-renderer .html5-video-player:not(.unstarted-mode) video[src]')];
                                                case 1:
                                                    _b.sent();
                                                    results = [];
                                                    selectors = [
                                                        'ytd-two-column-browse-results-renderer ytd-channel-video-player-renderer',
                                                    ];
                                                    return [4 /*yield*/, Promise.all(selectors.map(dom_1.waitForElement))];
                                                case 2:
                                                    elements = _b.sent();
                                                    try {
                                                        for (elements_1 = __values(elements), elements_1_1 = elements_1.next(); !elements_1_1.done; elements_1_1 = elements_1.next()) {
                                                            element = elements_1_1.value;
                                                            if (element &&
                                                                element.parentNode) {
                                                                parent_1 = element.parentNode;
                                                                nextSibling = element.nextSibling;
                                                                element.remove();
                                                                results.push({
                                                                    element: element,
                                                                    parent: parent_1,
                                                                    nextSibling: nextSibling,
                                                                });
                                                            }
                                                        }
                                                    }
                                                    catch (e_1_1) { e_1 = { error: e_1_1 }; }
                                                    finally {
                                                        try {
                                                            if (elements_1_1 && !elements_1_1.done && (_a = elements_1.return)) _a.call(elements_1);
                                                        }
                                                        finally { if (e_1) throw e_1.error; }
                                                    }
                                                    return [2 /*return*/, results];
                                                case 3:
                                                    error_1 = _b.sent();
                                                    return [3 /*break*/, 4];
                                                case 4: return [2 /*return*/];
                                            }
                                        });
                                    }); },
                                    onDisable: function (cachedElements) { return __awaiter(void 0, void 0, void 0, function () {
                                        var cachedElements_1, cachedElements_1_1, cached;
                                        var e_2, _a;
                                        return __generator(this, function (_b) {
                                            try {
                                                try {
                                                    for (cachedElements_1 = __values(cachedElements), cachedElements_1_1 = cachedElements_1.next(); !cachedElements_1_1.done; cachedElements_1_1 = cachedElements_1.next()) {
                                                        cached = cachedElements_1_1.value;
                                                        if (cached.parent &&
                                                            cached.element) {
                                                            cached.parent.insertBefore(cached.element, cached.nextSibling);
                                                        }
                                                    }
                                                }
                                                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                                                finally {
                                                    try {
                                                        if (cachedElements_1_1 && !cachedElements_1_1.done && (_a = cachedElements_1.return)) _a.call(cachedElements_1);
                                                    }
                                                    finally { if (e_2) throw e_2.error; }
                                                }
                                            }
                                            catch (e) {
                                                console.error(e);
                                            }
                                            return [2 /*return*/];
                                        });
                                    }); },
                                },
                            ],
                            storageKey: 'hideChannelTrailer',
                        },
                    ],
                    withoutCheckboxes: true,
                },
            ],
        },
        {
            title: 'Ads',
            settings: [
                {
                    title: 'YouTube Banners',
                    groups: [
                        {
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('youtube-banners'),
                                    selectors: ['ytd-banner-promo-renderer'],
                                },
                            ],
                            storageKey: 'adsYoutubeBanner',
                        },
                    ],
                    withoutCheckboxes: true,
                },
                {
                    title: 'Sponsored search results',
                    groups: [
                        {
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('sponsored-search'),
                                    selectors: ['ytd-search-pyv-renderer'],
                                },
                            ],
                            storageKey: 'adsSearchResults',
                        },
                    ],
                    withoutCheckboxes: true,
                },
                {
                    title: 'Sponsored feed video',
                    groups: [
                        {
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('sponsored-feed-video'),
                                    selectors: [
                                        'ytd-rich-item-renderer:has(ytd-ad-slot-renderer)',
                                    ],
                                },
                            ],
                            storageKey: 'adsFeedVideo',
                        },
                    ],
                    withoutCheckboxes: true,
                },
            ],
        },
        {
            title: 'Other',
            settings: [
                {
                    title: 'Hide Related videos',
                    groups: [
                        {
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-related-videos'),
                                    selectors: ['#related'],
                                },
                            ],
                            storageKey: 'relatedVideos',
                        },
                    ],
                },
                {
                    title: 'Right comment mode',
                    groups: [
                        {
                            actions: [
                                {
                                    urlRegExp: [const_1.UrlRegExps.Watch],
                                    attr: (0, getAttr_1.getAttr)(),
                                    action: config_1.ElementActions.custom,
                                    selectors: [],
                                },
                            ],
                            storageKey: 'rightCommentMode',
                        },
                    ],
                },
                {
                    title: 'Hide related video',
                    groups: [
                        {
                            actions: [
                                {
                                    action: config_1.ElementActions.hide,
                                    attr: (0, getAttr_1.getAttr)('hide-related-video-description'),
                                    selectors: [
                                        '#description #infocards-section',
                                    ],
                                },
                            ],
                            storageKey: 'hideDescriptionRelatedVideo',
                        },
                    ],
                },
            ],
        },
    ],
    storageActions: [],
};


/***/ }),

/***/ "./src/shared/const.ts":
/*!*****************************!*\
  !*** ./src/shared/const.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UrlRegExps = exports.BASE_ATTR_PREFIX = void 0;
exports.BASE_ATTR_PREFIX = 'cln-yt-cust';
var UrlRegExps;
(function (UrlRegExps) {
    UrlRegExps["Home"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/?$";
    UrlRegExps["Shorts"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/shorts\\/[^\\/\\?]+";
    UrlRegExps["Watch"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/watch\\?v=[^&]+";
    UrlRegExps["Channel"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+";
    UrlRegExps["ChannelVideos"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/videos\\/?$";
    UrlRegExps["ChannelShorts"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/shorts\\/?$";
    UrlRegExps["ChannelStreams"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/streams\\/?$";
    UrlRegExps["ChannelPlaylists"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/playlists\\/?$";
    UrlRegExps["ChannelCommunity"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/community\\/?$";
    UrlRegExps["ChannelChannels"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/channels\\/?$";
    UrlRegExps["ChannelAbout"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/(c|channel|@)[^\\/\\?]+\\/about\\/?$";
    UrlRegExps["Playlist"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/playlist\\?list=[^&]+";
    UrlRegExps["History"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/feed\\/history\\/?$";
    UrlRegExps["Subscriptions"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/feed\\/subscriptions\\/?$";
    UrlRegExps["Library"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/feed\\/library\\/?$";
    UrlRegExps["Trending"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/feed\\/trending\\/?$";
    UrlRegExps["Music"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/music\\/?$";
    UrlRegExps["Settings"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/account(_.*)?\\/?$";
    UrlRegExps["Search"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/results\\?search_query=.*";
    UrlRegExps["Notifications"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/notifications\\/?$";
    UrlRegExps["Live"] = "^https:\\/\\/(www\\.)?youtube\\.com\\/live\\/?$";
})(UrlRegExps = exports.UrlRegExps || (exports.UrlRegExps = {}));


/***/ }),

/***/ "./src/shared/storage/config.ts":
/*!**************************************!*\
  !*** ./src/shared/storage/config.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DEFAULT_STORAGE = void 0;
exports.DEFAULT_STORAGE = {
    isEnabled: true,
    hideShorts: { enabled: false },
    hideChannelBanner: { enabled: false },
    hideTranscriptSection: { enabled: false },
    adsFeedVideo: { enabled: false },
    persistentCommentSort: { enabled: false, value: 'popular' },
    persistentQuality: { enabled: false, value: '1080' },
    persistentPlaybackSpeed: { enabled: false, value: '1.00' },
    adsYoutubeBanner: { enabled: false },
    adsSearchResults: { enabled: false },
    hideChannelTrailer: { enabled: false },
    hideJams: { enabled: false },
    hideSearchTags: { enabled: false },
    hidePlayerSubtitlesButton: { enabled: false },
    hidePeopleMentioned: { enabled: false },
    hideDescriptionRelatedVideo: { enabled: false },
    hideSponsorVideo: { enabled: false },
    rightCommentMode: { enabled: false },
    hideEpisodesDescription: { enabled: false },
    hideCreateVideo: { enabled: false },
    voiceButtonInSearch: { enabled: false },
    hidePlayerWideSizePlayerButton: { enabled: false },
    hidePlayerMiniSizePlayerButton: { enabled: false },
    virtualKeyboard: { enabled: false },
    subscribeButton: { enabled: false },
    hideSponsorButton: { enabled: false },
    notificationButton: { enabled: false },
    relatedVideos: { enabled: false, maxVideo: 5 },
    hideLiveChat: { enabled: false },
    disableAutoplay: { enabled: false },
    commentsRightMode: { enabled: false },
    hideYourMovies: { enabled: false },
    hideNewsSection: { enabled: false },
    hidePlayerAutoplay: { enabled: false },
    autoOpenDescription: { enabled: false },
    hideMenuShorts: { enabled: false },
    hideMenuPlaylists: { enabled: false },
    hideMenuYourVideo: { enabled: false },
    hideMenuHistory: { enabled: false },
    hideMenuWatchLater: { enabled: false },
    hideMenuLikedVideos: { enabled: false },
    hideMenuSubscriptionsList: { enabled: false },
    hideMenuExploreMusic: { enabled: false },
    hideMenuExploreGaming: { enabled: false },
    hideMenuExploreSports: { enabled: false },
    hideMenuExploreNews: { enabled: false },
    hideMenuExploreTrending: { enabled: false },
    hideMenuMorePremium: { enabled: false },
    hideMenuMoreKids: { enabled: false },
    hideMenuMoreMusic: { enabled: false },
    hideMenuMoreStudio: { enabled: false },
};


/***/ }),

/***/ "./src/shared/types/config.ts":
/*!************************************!*\
  !*** ./src/shared/types/config.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ElementActions = void 0;
var ElementActions;
(function (ElementActions) {
    ElementActions["hide"] = "hide";
    ElementActions["click"] = "click";
    ElementActions["custom"] = "custom";
    ElementActions["dropdown"] = "dropdown";
})(ElementActions = exports.ElementActions || (exports.ElementActions = {}));


/***/ }),

/***/ "./src/shared/utils/dom.ts":
/*!*********************************!*\
  !*** ./src/shared/utils/dom.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.waitForElement = void 0;
var waitForElement = function (selector) {
    return new Promise(function (resolve) {
        var existing = document.querySelector(selector);
        if (existing)
            return resolve(existing);
        var observer = new MutationObserver(function () {
            var element = document.querySelector(selector);
            if (element) {
                observer.disconnect();
                resolve(element);
            }
        });
        observer.observe(document.documentElement, {
            childList: true,
            subtree: true,
        });
    });
};
exports.waitForElement = waitForElement;


/***/ }),

/***/ "./src/shared/utils/getAttr.ts":
/*!*************************************!*\
  !*** ./src/shared/utils/getAttr.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getAttr = void 0;
var const_1 = __webpack_require__(/*! src/shared/const */ "./src/shared/const.ts");
var generateId = function () {
    var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var result = '';
    for (var i = 0; i < 8; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
};
var getAttr = function (attr) {
    return "".concat(const_1.BASE_ATTR_PREFIX, "-").concat(attr ? attr : generateId());
};
exports.getAttr = getAttr;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/content/index.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=content.js.map